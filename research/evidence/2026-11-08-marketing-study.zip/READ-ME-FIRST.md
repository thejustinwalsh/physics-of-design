# Frozen marketing comparison evidence

Extract core and all image parts into the same directory. Frozen outputs retain exact bytes; use each frozen/public directory as a static origin root. Those pages need no Design Theory or local model at runtime. Source rebuilds require the supplied scaffold dependencies. Engine recipes also require matching toolkit/model provision and path rebinding; these archives do not bundle model binaries or dependencies.

Other public metadata is sanitized: account/auth events removed, host skill inventories omitted, local host/trial paths replaced by documented placeholders. EVIDENCE-MANIFEST.json maps original and published SHA256 per file. Original private files remain local. Do not compare sanitized stdout hashes directly to raw hashes in original receipts. Fonts retain original licenses and artwork provenance. Images belong to frozen author receipts or independent evaluator observations; neither is human preference evidence.

See repository/research/marketing-study/report.md for measured conclusions and limitations.
