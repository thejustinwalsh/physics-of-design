# Design Theory — build report

Completed November 8, 2026.

## Delivered

- `public/index.html` is the working entry point; serve `public/` as a static site.
- React implementation: `src/app.jsx`. StyleX supplies shared responsive page geometry, labels, actions and layout primitives. `public/base.css` supplies the editorial compositions, typography, responsive refinements and visual effects. All layouts use flexbox; no CSS grid.
- Supplied sculpture artwork and local Roboto Flex / Spectral fonts are used. The orbital mark, type specimen, palette and moving orbital composition are code-native SVG/CSS work.
- Complete journey: promise → six feature meanings → interactive coupled-choice specimen → four-step workflow → source checkout / build invitation.
- Features, How it works and Get started anchors; mobile navigation; approved GitHub destination; local `npm run build` copy action with an announced success state and a visible failure fallback.
- Three illustrative directions change type, weight, tracking, leading, spacing, color and replay duration together. Values are explicitly presented as an illustrative experiment, not measurements of beauty.
- Native scrolling drives image parallax and a middle-page transformation of the orbital composition. Controls remain stationary. Reduced motion removes spatial animation while preserving all content and interactions.
- The evidence boundary, optional-selector limitations, local-first scope, platform verification caveat, MIT license and contribution invitation are visible.

## Build

`npm run build` completed successfully with no build warnings. Its actual output is in `receipts/build.txt`. The supplied `build.mjs`, package manifest, original assets and dependencies were not edited. The supplied build writes a minimal HTML shell; React sets the product title and description when it starts.

To preview:

```sh
python3 -m http.server 4173 --directory public
```

To repeat verification against that server:

```sh
node src/verify.mjs
```

## Actual checks

The final browser run completed 27 passing checks with no page runtime errors or failed local HTTP requests. Machine-readable results are in `receipts/checks.json`; screenshots are in `receipts/`.

- Chromium: desktop 1440 × 1000, iPad-size 768 × 1024, phone 390 × 844. Full-page and first-screen screenshots captured and visually inspected for the three layouts.
- WebKit: all three sizes loaded with fonts and artwork, no horizontal page overflow, and a working specimen direction change. Full-page screenshots captured; phone output visually inspected.
- Resize sweep: 24 widths from 160 through 2200 CSS pixels, including either side of responsive transitions. No horizontal page overflow in that sweep. These are test samples, not configured viewport bounds.
- Longer replacement headings and paragraph content: phone, iPad-size and desktop reflowed without horizontal page overflow. Captured full-page receipts; desktop changed-copy output visually inspected.
- 200% text enlargement: computed text sizes doubled in the in-memory DOM at all three sizes, without horizontal page overflow. Captured receipts; phone and iPad-size outputs visually inspected. This is a text enlargement simulation, not physical browser UI zoom.
- Keyboard: skip-to-content, visible 3px focus outline, Features anchor, specimen choice by Space, mobile menu by Enter/Space, Escape dismissal with focus restoration, and keyboard navigation to Get started.
- Pointer: direction selection changes the actual font, spacing and color; replay starts its animation. Exactly one direction is pressed at a time.
- Emulated touch: mobile menu, Features link and expressive specimen choice.
- Clipboard: the browser clipboard received exactly `npm run build`; visible live status confirmed success. An injected rejected clipboard write produced the manual-copy fallback and retained the selectable command.
- Links: all nine internal anchor destinations resolved; all three external links used the approved repository URL. No external site was opened.
- Motion: two native scroll positions produced different middle-scene transforms. Reduced-motion mode kept that transform static, disabled smooth scrolling and specimen animation, and retained working direction selection.
- Contrast: six sampled solid-surface text combinations met 4.5:1 or higher, including the primary CTA, prose, type specimen label, get-started prose, copy status and footer note. All three interactive specimen palettes also met 4.5:1 or higher. This is a scoped check, not a claim of a full accessibility audit.
- Fonts and meaningful image alternatives loaded successfully. Single top-level heading verified.

Scroll work is event-driven and batched into one requested frame, skips hidden/offscreen scenes, and has listener/frame cleanup. Specimen replay frames and timers are disposed on unmount. There is no continuously running rendering loop or scroll trapping.

## Failures and limits

No unresolved failure remains in the performed site checks. An initial browser launch was blocked by the process sandbox; the same local browser verification subsequently ran successfully with reviewed execution permission. One initial replay test sampled before the requested animation frame; it was corrected to wait for the actual animation state. The local formatter launcher had a module-resolution error; formatting succeeded through the installed Prettier module instead. No supplied dependency was changed.

Physical iPhone/iPad hardware, Safari itself, assistive screen readers, browser UI zoom, exhaustive image-composite contrast, and production hosting were not verified. WebKit and touch results are browser emulation. Repository availability and upstream setup steps were not fetched or executed; only the supplied destination and source-checkout build command were used. JavaScript is required to render this React site, as in the supplied build pipeline. Clipboard availability depends on a secure context and browser permission; the visible fallback covers rejection.

## Assistance and boundary

Implemented independently by this Codex agent using only the supplied brief, design direction, content, local assets, installed dependencies, local shell, image viewing and Playwright. No child agents, other builder models, external inference, external research, image generation, asset/package downloads, prior implementations or study runs were used. Supplied sculpture provenance was read only to understand the supplied artwork; its external source path was not accessed.
