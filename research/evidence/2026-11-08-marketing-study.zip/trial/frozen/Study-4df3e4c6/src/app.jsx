import React, { useEffect, useRef, useState } from "react";
import { createRoot } from "react-dom/client";
import * as stylex from "@stylexjs/stylex";

const repo = "https://github.com/thejustinwalsh/physics-of-design";
const styles = stylex.create({
  shell: {
    maxWidth: 1600,
    marginInline: "auto",
    paddingInline: {
      default: 64,
      "@media (max-width: 1100px)": 36,
      "@media (max-width: 600px)": 22,
    },
  },
  row: { display: "flex", alignItems: "center" },
  between: { justifyContent: "space-between" },
  column: { display: "flex", flexDirection: "column" },
  label: {
    fontSize: 12,
    fontWeight: 650,
    letterSpacing: "0.09em",
    textTransform: "uppercase",
    lineHeight: 1.5,
  },
  button: {
    display: "inline-flex",
    alignItems: "center",
    justifyContent: "center",
    gap: 28,
    minHeight: 52,
    paddingInline: 24,
    borderRadius: 3,
    fontSize: 14,
    fontWeight: 600,
    textDecoration: "none",
    transitionProperty: "background-color, color",
    transitionDuration: "180ms",
  },
  primary: {
    backgroundColor: "#c63821",
    color: "#fff9ed",
    ":hover": { backgroundColor: "#ad2d18" },
  },
  light: {
    backgroundColor: "#f2efe6",
    color: "#25251f",
    ":hover": { backgroundColor: "#fffaf0" },
  },
  textLink: {
    display: "inline-flex",
    gap: 16,
    alignItems: "center",
    fontSize: 14,
    fontWeight: 600,
    textUnderlineOffset: 5,
  },
});
function Arrow({ diagonal = false, ...props }) {
  return (
    <svg
      width="18"
      height="18"
      viewBox="0 0 24 24"
      fill="none"
      aria-hidden="true"
      {...props}
    >
      <path
        d={diagonal ? "M5 19 19 5M5 5h14v14" : "M4 12h16m-6-6 6 6-6 6"}
        stroke="currentColor"
        strokeWidth="1.5"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
    </svg>
  );
}
function Mark() {
  return (
    <svg
      width="35"
      height="35"
      viewBox="0 0 40 40"
      fill="none"
      aria-hidden="true"
    >
      <circle cx="20" cy="20" r="12.5" stroke="currentColor" strokeWidth="2" />
      <ellipse
        cx="20"
        cy="20"
        rx="19"
        ry="6.8"
        transform="rotate(-42 20 20)"
        stroke="currentColor"
        strokeWidth="1.7"
      />
      <circle cx="31" cy="9" r="3.5" fill="currentColor" />
    </svg>
  );
}
function classes(name, ...rules) {
  return [name, stylex.props(...rules).className].filter(Boolean).join(" ");
}
function Label({ children, className = "" }) {
  return (
    <p className={classes("eyebrow " + className, styles.label)}>{children}</p>
  );
}

function useScrollScenes() {
  useEffect(() => {
    const media = window.matchMedia("(prefers-reduced-motion: reduce)");
    let raf = 0;
    const update = () => {
      raf = 0;
      if (document.hidden || media.matches) return;
      document.querySelectorAll("[data-parallax]").forEach((el) => {
        const r = el.parentElement.getBoundingClientRect();
        if (r.bottom < 0 || r.top > innerHeight) return;
        const rate = Number(el.dataset.parallax);
        el.style.setProperty(
          "--shift",
          `${(innerHeight / 2 - (r.top + r.height / 2)) * rate}px`,
        );
      });
      const scene = document.querySelector(".relationship-scene");
      if (scene) {
        const r = scene.getBoundingClientRect();
        if (r.bottom > 0 && r.top < innerHeight) {
          const progress = Math.max(
            0,
            Math.min(1, (innerHeight - r.top) / (innerHeight + r.height)),
          );
          scene.style.setProperty("--turn", `${-22 + progress * 70}deg`);
          scene.style.setProperty("--spread", `${40 - progress * 65}px`);
        }
      }
    };
    const schedule = () => {
      if (!raf && !media.matches) raf = requestAnimationFrame(update);
    };
    const reset = () => {
      if (media.matches) {
        document
          .querySelectorAll("[data-parallax]")
          .forEach((el) => el.style.removeProperty("--shift"));
        document
          .querySelector(".relationship-scene")
          ?.style.removeProperty("--turn");
        document
          .querySelector(".relationship-scene")
          ?.style.removeProperty("--spread");
      } else schedule();
    };
    addEventListener("scroll", schedule, { passive: true });
    addEventListener("resize", schedule);
    document.addEventListener("visibilitychange", schedule);
    media.addEventListener("change", reset);
    schedule();
    return () => {
      cancelAnimationFrame(raf);
      removeEventListener("scroll", schedule);
      removeEventListener("resize", schedule);
      document.removeEventListener("visibilitychange", schedule);
      media.removeEventListener("change", reset);
    };
  }, []);
}
const directions = {
  calm: {
    name: "Quiet",
    title: "Space to\nthink.",
    description:
      "A slower rhythm. Softer contrast. Room for the words to breathe.",
    font: '"Spectral", Georgia, serif',
    weight: 400,
    tracking: "-0.045em",
    leading: 1.07,
    space: "36px",
    accent: "#534d37",
    paper: "#e9e5d8",
    duration: 1600,
    type: "Serif / 400",
    rhythm: "Generous",
    motion: "1.6s / ease",
  },
  balanced: {
    name: "Balanced",
    title: "Find your\nfocus.",
    description: "A clear voice. A steady rhythm. Every element has a place.",
    font: '"Roboto Flex", sans-serif',
    weight: 560,
    tracking: "-0.055em",
    leading: 0.98,
    space: "28px",
    accent: "#a43826",
    paper: "#f0d9c9",
    duration: 1000,
    type: "Sans / 560",
    rhythm: "Open",
    motion: "1s / ease",
  },
  bold: {
    name: "Expressive",
    title: "Make some\nnoise.",
    description:
      "A louder voice. Tighter rhythm. A little more forward momentum.",
    font: '"Roboto Flex", sans-serif',
    weight: 850,
    tracking: "-0.065em",
    leading: 0.9,
    space: "20px",
    accent: "#932318",
    paper: "#f1b7a4",
    duration: 600,
    type: "Sans / 850",
    rhythm: "Compact",
    motion: "0.6s / ease",
  },
};
function Demo() {
  const [direction, setDirection] = useState("balanced");
  const [playing, setPlaying] = useState(false);
  const timer = useRef(null);
  const replayFrame = useRef(0);
  const d = directions[direction];
  useEffect(
    () => () => {
      clearTimeout(timer.current);
      cancelAnimationFrame(replayFrame.current);
    },
    [],
  );
  function replay() {
    setPlaying(false);
    cancelAnimationFrame(replayFrame.current);
    replayFrame.current = requestAnimationFrame(() => {
      setPlaying(true);
      clearTimeout(timer.current);
      timer.current = setTimeout(() => setPlaying(false), 2000);
    });
  }
  return (
    <section
      id="playground"
      className="demo-section"
      aria-labelledby="demo-title"
    >
      <div {...stylex.props(styles.shell)}>
        <div className="section-heading">
          <div>
            <Label>02 / A small experiment</Label>
            <h2 id="demo-title">
              One choice.
              <br /> <span className="serif">A different feeling.</span>
            </h2>
          </div>
          <p>
            Good design is a relationship.
            <br /> Change the direction and watch the details move together.
          </p>
        </div>
        <div className="playground">
          <div className="demo-controls">
            <div>
              <Label>Choose a direction</Label>
              <div
                className="direction-options"
                role="group"
                aria-label="Design direction"
              >
                {Object.entries(directions).map(([key, item]) => (
                  <button
                    key={key}
                    aria-pressed={direction === key}
                    onClick={() => {
                      cancelAnimationFrame(replayFrame.current);
                      setDirection(key);
                      setPlaying(false);
                    }}
                  >
                    {item.name}
                    <span aria-hidden="true">↗</span>
                  </button>
                ))}
              </div>
            </div>
            <p className="demo-note">
              These choices are illustrative.
              <br /> You bring the taste. The tools help you explore and check
              it.
            </p>
          </div>
          <div
            className={`specimen ${playing ? "playing" : ""}`}
            style={{
              "--spec-font": d.font,
              "--spec-weight": d.weight,
              "--spec-tracking": d.tracking,
              "--spec-leading": d.leading,
              "--spec-space": d.space,
              "--spec-accent": d.accent,
              "--spec-paper": d.paper,
              "--spec-duration": `${d.duration}ms`,
            }}
          >
            <div className="specimen-top">
              <span>FIELD NOTES — VOL. 01</span>
              <span className="spec-orbit" aria-hidden="true">
                <i />
              </span>
            </div>
            <div className="specimen-content">
              <h3>{d.title}</h3>
              <p>{d.description}</p>
            </div>
            <div className="specimen-bottom">
              <span>A STUDY IN POSSIBILITY</span>
              <button onClick={replay} aria-label="Replay specimen motion">
                <span aria-hidden="true">↻</span> Replay motion
              </button>
            </div>
          </div>
          <div className="demo-values" aria-live="polite" aria-atomic="true">
            <p>
              <span>Typography</span>
              <strong>{d.type}</strong>
            </p>
            <p>
              <span>Spacing</span>
              <strong>{d.rhythm}</strong>
            </p>
            <p>
              <span>Motion</span>
              <strong>{d.motion}</strong>
            </p>
            <span className="coupled">
              <svg
                width="15"
                height="15"
                viewBox="0 0 20 20"
                fill="none"
                aria-hidden="true"
              >
                <path
                  d="m7 13 6-6M8 6l2-2a4 4 0 0 1 6 6l-2 2M6 8l-2 2a4 4 0 0 0 6 6l2-2"
                  stroke="currentColor"
                  strokeWidth="1.4"
                />
              </svg>{" "}
              Connected, by design.
            </span>
          </div>
        </div>
      </div>
    </section>
  );
}
function App() {
  const [menu, setMenu] = useState(false);
  const [copyState, setCopyState] = useState("idle");
  const copyTimer = useRef(null);
  useScrollScenes();
  useEffect(() => {
    document.title = "Design Theory — Make every choice work together.";
    const meta = document.createElement("meta");
    meta.name = "description";
    meta.content =
      "A local-first toolkit for coding agents. Explore typography, color, layout and motion as one connected design.";
    document.head.appendChild(meta);
    return () => {
      meta.remove();
      clearTimeout(copyTimer.current);
    };
  }, []);
  useEffect(() => {
    if (!menu) return;
    const close = (e) => {
      if (e.key === "Escape") {
        setMenu(false);
        document.querySelector(".menu-toggle")?.focus();
      }
    };
    document.addEventListener("keydown", close);
    return () => document.removeEventListener("keydown", close);
  }, [menu]);
  async function copy() {
    try {
      await navigator.clipboard.writeText("npm run build");
      setCopyState("success");
    } catch {
      setCopyState("failure");
    }
    clearTimeout(copyTimer.current);
    copyTimer.current = setTimeout(() => setCopyState("idle"), 6000);
  }
  return (
    <>
      <a className="skip-link" href="#main">
        Skip to content
      </a>
      <header className="site-header">
        <div {...stylex.props(styles.shell, styles.row, styles.between)}>
          <a className="brand" href="#" aria-label="Design Theory home">
            <Mark />
            <span>Design Theory</span>
          </a>
          <button
            className="menu-toggle"
            aria-expanded={menu}
            aria-controls="navigation"
            onClick={() => setMenu(!menu)}
          >
            {menu ? "Close" : "Menu"}
            <span aria-hidden="true">{menu ? "−" : "+"}</span>
          </button>
          <nav
            id="navigation"
            aria-label="Main navigation"
            className={menu ? "open" : ""}
          >
            <a href="#features" onClick={() => setMenu(false)}>
              Features
            </a>
            <a href="#how-it-works" onClick={() => setMenu(false)}>
              How it works
            </a>
            <a href="#get-started" onClick={() => setMenu(false)}>
              Get started <Arrow diagonal />
            </a>
          </nav>
        </div>
      </header>
      <main id="main">
        <section className="hero" aria-labelledby="hero-title">
          <div className={classes("hero-inner", styles.shell)}>
            <div className="hero-copy">
              <Label>
                <span className="live-dot" /> The physics of better interfaces
              </Label>
              <h1 id="hero-title">
                Make every
                <br /> choice work
                <br /> <span className="serif">together.</span>
              </h1>
              <p>
                A local-first toolkit for coding agents.
                <br className="desktop-break" /> Explore typography, color,
                layout and motion as one connected design.
              </p>
              <div className="hero-actions">
                <a
                  href="#features"
                  {...stylex.props(styles.button, styles.primary)}
                >
                  Explore the tools <Arrow />
                </a>
                <a href={repo} {...stylex.props(styles.textLink)}>
                  View on GitHub <Arrow diagonal />
                </a>
              </div>
              <span className="hero-footnote">
                Your direction. More possibilities.
              </span>
            </div>
            <div className="hero-art">
              <img
                src="assets/sculpture.png"
                alt="A vermilion lacquer ring, rough chalk sphere, chrome ribbon and amber glass held in balance."
                fetchPriority="high"
                data-parallax="0.09"
              />
              <div className="image-caption">
                <span>FIG. 01 — FORCES IN BALANCE</span>
                <span aria-hidden="true">↙</span>
              </div>
              <span className="art-coordinate" aria-hidden="true">
                FORM / FEELING / FUNCTION
              </span>
            </div>
          </div>
          <div
            className={classes(
              "hero-bottom",
              styles.shell,
              styles.row,
              styles.between,
            )}
          >
            <span>
              Built for creative minds.
              <br className="mobile-break" /> And the agents they work with.
            </span>
            <a href="#features" className="scroll-cue">
              A closer look <span aria-hidden="true">↓</span>
            </a>
          </div>
        </section>
        <section
          id="features"
          className="features"
          aria-labelledby="features-title"
        >
          <div {...stylex.props(styles.shell)}>
            <div className="section-heading">
              <div>
                <Label>01 / The connected toolkit</Label>
                <h2 id="features-title">
                  Nothing works
                  <br /> <span className="serif">in isolation.</span>
                </h2>
              </div>
              <p>
                A type choice changes a line break.
                <br /> A little space changes the pace.
                <br /> Work with the relationships.
              </p>
            </div>
            <div className="feature-pair">
              <div className="type-art">
                <div className="spec-label">
                  <span>TYPE + COLOR</span>
                  <span>01—02</span>
                </div>
                <div className="aa" aria-hidden="true">
                  <span>A</span>
                  <span>a</span>
                  <i className="type-guide one" />
                  <i className="type-guide two" />
                </div>
                <div className="palette" aria-hidden="true">
                  <i />
                  <i />
                  <i />
                  <i />
                  <i />
                </div>
                <div className="type-caption">
                  Character is a system of small decisions.
                </div>
              </div>
              <div className="feature-copy">
                <h3>
                  A voice.
                  <br /> In every detail.
                </h3>
                <div className="feature-description">
                  <span className="feature-number">01</span>
                  <div>
                    <h4>Typography that holds together</h4>
                    <p>
                      Shape type, tracking, leading and line breaks together.
                      Explore variable axes and font metrics, then verify the
                      actual browser or native result.
                    </p>
                  </div>
                </div>
                <div className="feature-description">
                  <span className="feature-number">02</span>
                  <div>
                    <h4>Color with a purpose</h4>
                    <p>
                      Explore perceptual OKLCH palettes, give colors a role and
                      check text contrast where it lives. Choose the harmony.
                      Check the legibility.
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div className="relationship-scene">
            <div className={classes("relationship-inner", styles.shell)}>
              <div className="relationship-copy">
                <Label>03—04 / Space + time</Label>
                <h3>
                  Give your
                  <br /> ideas <span className="serif">room.</span>
                  <br /> Then let
                  <br /> them move.
                </h3>
                <p>
                  Hierarchy, grouping and whitespace that respond to content.
                  Editable motion that gives tension, timing and release a
                  purpose.
                </p>
                <span className="motion-note">
                  Made to adapt. Including to reduced motion.
                </span>
              </div>
              <div className="orbit-art" aria-hidden="true">
                <div className="orbit-disc">
                  <div className="orbit-halo" />
                  <div className="orbit-ring ring-one" />
                  <div className="orbit-ring ring-two" />
                  <div className="orbit-center" />
                  <div className="orbit-small" />
                </div>
                <span className="orbit-axis">LAYOUT ↔ MOTION</span>
                <span className="orbit-bottom">A SHIFT IN PERSPECTIVE.</span>
              </div>
            </div>
          </div>
          <div {...stylex.props(styles.shell)}>
            <div className="feature-pair material-pair">
              <div className="material-art">
                <img
                  src="assets/sculpture.png"
                  alt="Close-up of chalk texture, reflective chrome and translucent amber glass in warm studio light."
                  loading="lazy"
                  data-parallax="0.07"
                />
                <span className="material-tag">05—06 / SURFACE + MEMORY</span>
              </div>
              <div className="feature-copy">
                <h3>
                  Feel the finish.
                  <br /> <span className="serif">Keep the thinking.</span>
                </h3>
                <div className="feature-description">
                  <span className="feature-number">05</span>
                  <div>
                    <h4>Materials and light</h4>
                    <p>
                      Explore texture, roughness and light response. DOM
                      finishes are approximations; dedicated graphics can use
                      PBR. Check readability on the final composite.
                    </p>
                  </div>
                </div>
                <div className="feature-description">
                  <span className="feature-number">06</span>
                  <div>
                    <h4>Decisions you can revisit</h4>
                    <p>
                      Keep alternatives and the reasons behind them. An optional
                      local selector helps choose among viable paths. Replay
                      saved paths without another model call when inputs still
                      match.
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>
        <Demo />
        <section
          id="how-it-works"
          className="workflow"
          aria-labelledby="workflow-title"
        >
          <div {...stylex.props(styles.shell)}>
            <div className="section-heading">
              <div>
                <Label>03 / From intention to interface</Label>
                <h2 id="workflow-title">
                  Keep your taste.
                  <br /> <span className="serif">Build on it.</span>
                </h2>
              </div>
              <p>
                Make a direction tangible.
                <br /> Then make it something you can return to.
              </p>
            </div>
            <div className="workflow-steps">
              {[
                [
                  "01",
                  "Set a direction",
                  "Start with your audience, content and visual intent. Record the brief in DESIGN.md.",
                ],
                [
                  "02",
                  "Explore the relationships",
                  "Compare connected alternatives. See what changes when the choices work together.",
                ],
                [
                  "03",
                  "Measure the result",
                  "Use real font shaping and browser or native geometry. Catch wrapping, clipping and broken constraints.",
                ],
                [
                  "04",
                  "Keep the good path",
                  "Save the decisions. Revisit the values. Revalidate when the content or context changes.",
                ],
              ].map(([n, title, body]) => (
                <article key={n}>
                  <div className="step-top">
                    <span>{n}</span>
                    <span aria-hidden="true">{n === "04" ? "↗" : "→"}</span>
                  </div>
                  <h3>{title}</h3>
                  <p>{body}</p>
                </article>
              ))}
            </div>
            <div className="tooling-note">
              <Mark />
              <p>
                Unix-composable TypeScript CLI. JSON output. Thin MCP wrappers.
                <br />{" "}
                <span>
                  Optional interactive specimens and component inspection. React
                  + StyleX and React Native mappings, with verification for each
                  platform.
                </span>
              </p>
            </div>
          </div>
        </section>
        <section
          id="get-started"
          className="get-started"
          aria-labelledby="start-title"
        >
          <div className={classes("start-inner", styles.shell)}>
            <div className="start-copy">
              <Label>
                <span className="live-dot" /> Local first. Open source.
              </Label>
              <h2 id="start-title">
                Your next idea.
                <br /> <span className="serif">More considered.</span>
              </h2>
              <p>
                Start with your brief. Keep your taste.
                <br /> Get the source, follow its setup instructions,
                <br className="desktop-break" /> then build locally.
              </p>
              <a href={repo} {...stylex.props(styles.button, styles.light)}>
                Get the source <Arrow diagonal />
              </a>
            </div>
            <div className="start-detail">
              <div className="command-label">
                <span>IN YOUR SOURCE CHECKOUT</span>
                <span aria-hidden="true">↙</span>
              </div>
              <div className="command">
                <code>
                  <span aria-hidden="true">$ </span>npm run build
                </code>
                <button onClick={copy} aria-label="Copy command npm run build">
                  <svg
                    width="19"
                    height="19"
                    viewBox="0 0 24 24"
                    fill="none"
                    aria-hidden="true"
                  >
                    <rect
                      x="8"
                      y="8"
                      width="12"
                      height="13"
                      rx="2"
                      stroke="currentColor"
                      strokeWidth="1.4"
                    />
                    <path
                      d="M15 8V4a1 1 0 0 0-1-1H4a1 1 0 0 0-1 1v11a1 1 0 0 0 1 1h4"
                      stroke="currentColor"
                      strokeWidth="1.4"
                    />
                  </svg>
                  {copyState === "success" ? "Copied!" : "Copy command"}
                </button>
              </div>
              <p
                className={`copy-status ${copyState === "failure" ? "copy-error" : ""}`}
                role="status"
              >
                {copyState === "success"
                  ? "Copied to clipboard. Ready for your local checkout."
                  : copyState === "failure"
                    ? "Couldn’t copy. Select and copy “npm run build” above."
                    : "Build command for the source checkout. See the repository for setup."}
              </p>
              <div className="start-facts">
                <p>
                  Local-first after provisioning.
                  <br /> Your application stays ordinary application code.
                </p>
                <p>
                  The optional evaluator is a separate choice.
                  <br /> No required service to ship.
                </p>
              </div>
            </div>
          </div>
        </section>
      </main>
      <footer>
        <div {...stylex.props(styles.shell)}>
          <div className="footer-top">
            <a href="#" className="brand">
              <Mark />
              <span>Design Theory</span>
            </a>
            <span>A little rigor. A lot of possibility.</span>
            <a href={repo} {...stylex.props(styles.textLink)}>
              GitHub <Arrow diagonal />
            </a>
          </div>
          <div className="footer-bottom">
            <p>
              Research in progress. Better design preference and lower overall
              build-token use have not yet been established. The optional
              selector is not an aesthetic judge or factual verifier.
            </p>
            <p>
              MIT-licensed. Pay it forward.
              <br /> Contribute a fix. Make the next build better.
            </p>
            <a href="#">Back to top ↑</a>
          </div>
        </div>
      </footer>
    </>
  );
}
createRoot(document.getElementById("root")).render(<App />);
