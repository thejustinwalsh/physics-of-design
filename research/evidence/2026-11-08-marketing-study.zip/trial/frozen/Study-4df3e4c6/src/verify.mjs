import { chromium, webkit } from "playwright";
import { writeFile } from "node:fs/promises";
import assert from "node:assert/strict";
import Color from "colorjs.io";
const receipt = {
  date: new Date().toISOString(),
  checks: [],
  errors: [],
  screenshots: [],
  notes: [],
};
const check = (name, details = true) => {
  receipt.checks.push({ name, details });
  console.log("PASS", name, JSON.stringify(details));
};
const browser = await chromium.launch();
const context = await browser.newContext({
  viewport: { width: 1440, height: 1000 },
  permissions: ["clipboard-read", "clipboard-write"],
});
const page = await context.newPage();
page.on("pageerror", (e) => receipt.errors.push(e.message));
page.on("response", (r) => {
  if (r.status() >= 400) receipt.errors.push(`${r.status()} ${r.url()}`);
});
const load = async () => {
  await page.goto("http://localhost:4173");
  await page.evaluate(() => document.fonts.ready);
};
const shot = async (name, fullPage = false) => {
  await page.screenshot({ path: `receipts/${name}.png`, fullPage });
  receipt.screenshots.push(name + ".png");
};
const fits = async () =>
  page.evaluate(() => ({
    width: innerWidth,
    scrollWidth: document.documentElement.scrollWidth,
    body: document.body.scrollWidth,
  }));
await load();
assert.match(await page.title(), /^Design Theory/);
assert.equal(await page.locator("h1").count(), 1);
assert.equal(
  await page
    .locator("img")
    .evaluateAll((els) =>
      els.every(
        (el) => el.complete && el.naturalWidth > 0 && el.alt.length > 0,
      ),
    ),
  true,
);
assert.equal(
  await page.evaluate(
    () =>
      document.fonts.check('500 20px "Roboto Flex"') &&
      document.fonts.check("20px Spectral"),
  ),
  true,
);
check("Title, heading, supplied artwork and fonts loaded");
for (const [name, width, height] of [
  ["desktop", 1440, 1000],
  ["ipad", 768, 1024],
  ["phone", 390, 844],
]) {
  await page.setViewportSize({ width, height });
  await load();
  await shot(name + "-top");
  await shot(name + "-full", true);
  const size = await fits();
  assert.equal(size.scrollWidth, width);
  check(name + " layout has no horizontal overflow", size);
}
await page.setViewportSize({ width: 1440, height: 1000 });
await load();
const anchors = await page
  .locator('a[href^="#"]')
  .evaluateAll((els) =>
    els.map((e) => ({
      href: e.getAttribute("href"),
      exists:
        e.getAttribute("href") === "#" ||
        !!document.querySelector(e.getAttribute("href")),
    })),
  );
assert(anchors.every((a) => a.exists));
const repoLinks = await page
  .locator('a[href^="https"]')
  .evaluateAll((els) => els.map((e) => e.href));
assert(
  repoLinks.length >= 3 &&
    repoLinks.every(
      (h) => h === "https://github.com/thejustinwalsh/physics-of-design",
    ),
);
check("All internal anchors resolve and repository links use approved URL", {
  internal: anchors.length,
  repository: repoLinks.length,
});
await page.keyboard.press("Tab");
assert.equal(
  await page.evaluate(() => document.activeElement.textContent),
  "Skip to content",
);
await page.keyboard.press("Enter");
assert.equal(await page.evaluate(() => location.hash), "#main");
check("Keyboard skip link works");
await page.locator('a[href="#features"]').first().focus();
const focus = await page
  .locator('a[href="#features"]')
  .first()
  .evaluate((el) => ({
    style: getComputedStyle(el).outlineStyle,
    width: getComputedStyle(el).outlineWidth,
  }));
assert.equal(focus.style, "solid");
assert.equal(focus.width, "3px");
await page.keyboard.press("Enter");
assert.equal(await page.evaluate(() => location.hash), "#features");
check("Visible keyboard focus and Features anchor", focus);
await page.locator("button[aria-pressed]").filter({ hasText: "Quiet" }).click();
assert.match(await page.locator(".specimen h3").textContent(), /Space to/);
assert.equal(
  await page.locator('.direction-options button[aria-pressed="true"]').count(),
  1,
);
assert.match(await page.locator(".demo-values").textContent(), /Serif \/ 400/);
await page.waitForFunction(
  () =>
    getComputedStyle(document.querySelector(".specimen")).color ===
    "rgb(83, 77, 55)",
);
const quiet = await page
  .locator(".specimen")
  .evaluate((el) => ({
    color: getComputedStyle(el).color,
    gap: getComputedStyle(el.querySelector(".specimen-content p")).marginTop,
    font: getComputedStyle(el.querySelector("h3")).fontFamily,
  }));
await page
  .locator(".direction-options button")
  .filter({ hasText: "Expressive" })
  .focus();
await page.keyboard.press("Space");
assert.match(await page.locator(".specimen h3").textContent(), /Make some/);
assert.match(await page.locator(".demo-values").textContent(), /Sans \/ 850/);
await page.waitForFunction(
  () =>
    getComputedStyle(document.querySelector(".specimen")).color ===
    "rgb(147, 35, 24)",
);
const expressive = await page
  .locator(".specimen")
  .evaluate((el) => ({
    color: getComputedStyle(el).color,
    gap: getComputedStyle(el.querySelector(".specimen-content p")).marginTop,
    font: getComputedStyle(el.querySelector("h3")).fontFamily,
  }));
assert.notEqual(quiet.color, expressive.color);
assert.notEqual(quiet.gap, expressive.gap);
assert.notEqual(quiet.font, expressive.font);
await page.getByRole("button", { name: "Replay specimen motion" }).click();
await page.waitForFunction(
  () =>
    getComputedStyle(document.querySelector(".specimen-content"))
      .animationName === "spec-reveal",
);
check(
  "Pointer and keyboard change coupled type, color, spacing and replay timing",
  { quiet, expressive },
);
await shot("demo-expressive");
await page
  .locator(".direction-options button")
  .filter({ hasText: "Balanced" })
  .click();
await page.getByRole("button", { name: "Copy command npm run build" }).click();
assert.equal(
  await page.evaluate(() => navigator.clipboard.readText()),
  "npm run build",
);
assert.match(
  await page.getByRole("status").textContent(),
  /Copied to clipboard/,
);
check("Copy command writes exact command and announces success");
await page.evaluate(() =>
  Object.defineProperty(navigator, "clipboard", {
    configurable: true,
    value: {
      writeText: async () => {
        throw new Error("Test permission denied");
      },
    },
  }),
);
await page.getByRole("button", { name: "Copy command npm run build" }).click();
assert.match(await page.getByRole("status").textContent(), /Couldn’t copy/);
assert.equal(
  await page.locator(".command code").textContent(),
  "$ npm run build",
);
check("Clipboard failure gives visible manual-copy fallback");
await page.evaluate(() => delete navigator.clipboard);
await page.setViewportSize({ width: 390, height: 844 });
await load();
await page.getByRole("button", { name: "Menu" }).focus();
await page.keyboard.press("Enter");
assert.equal(
  await page
    .getByRole("button", { name: "Close" })
    .getAttribute("aria-expanded"),
  "true",
);
await page.keyboard.press("Escape");
assert.equal(
  await page
    .getByRole("button", { name: "Menu" })
    .getAttribute("aria-expanded"),
  "false",
);
assert.equal(
  await page.evaluate(() => document.activeElement.className),
  "menu-toggle",
);
await page.keyboard.press("Space");
await page.keyboard.press("Tab");
assert.equal(
  await page.evaluate(() => document.activeElement.textContent),
  "Features",
);
await page.keyboard.press("Tab");
await page.keyboard.press("Tab");
assert.match(
  await page.evaluate(() => document.activeElement.textContent),
  /Get started/,
);
await page.keyboard.press("Enter");
assert.equal(await page.evaluate(() => location.hash), "#get-started");
assert.equal(
  await page
    .getByRole("button", { name: "Menu" })
    .getAttribute("aria-expanded"),
  "false",
);
check(
  "Phone menu opens by keyboard, Escape restores focus, anchor closes menu",
);
await page.setViewportSize({ width: 1440, height: 1000 });
await load();
const scene = page.locator(".relationship-scene");
await page.evaluate(() => {
  const el = document.querySelector(".relationship-scene");
  scrollTo(0, el.offsetTop - 650);
});
await page.waitForTimeout(600);
const before = await scene.evaluate((el) =>
  el.style.getPropertyValue("--turn"),
);
await page.evaluate(() => scrollBy(0, 500));
await page.waitForTimeout(600);
const after = await scene.evaluate((el) => el.style.getPropertyValue("--turn"));
assert.notEqual(before, after);
const parallax = await page
  .locator(".material-art img")
  .evaluate((el) => el.style.getPropertyValue("--shift"));
check("Middle composition changes with native scroll", { before, after });
await shot("desktop-motion");
await page.emulateMedia({ reducedMotion: "reduce" });
await page.waitForTimeout(50);
const calmBefore = await page
  .locator(".orbit-disc")
  .evaluate((el) => getComputedStyle(el).transform);
await page.evaluate(() => scrollBy(0, 160));
await page.waitForTimeout(50);
const calmAfter = await page
  .locator(".orbit-disc")
  .evaluate((el) => getComputedStyle(el).transform);
assert.equal(calmBefore, calmAfter);
assert.equal(
  await page.evaluate(
    () => getComputedStyle(document.documentElement).scrollBehavior,
  ),
  "auto",
);
await page
  .locator(".direction-options button")
  .filter({ hasText: "Quiet" })
  .click();
assert.match(await page.locator(".specimen h3").textContent(), /Space to/);
await page.getByRole("button", { name: "Replay specimen motion" }).click();
assert.equal(
  await page
    .locator(".specimen-content")
    .evaluate((el) => getComputedStyle(el).animationName),
  "none",
);
check(
  "Reduced motion removes parallax and animations while preserving direction controls",
);
await shot("reduced-motion-demo");
const widths = [
  160, 200, 240, 280, 320, 360, 390, 480, 599, 600, 601, 720, 768, 800, 801,
  900, 1024, 1100, 1101, 1280, 1440, 1600, 1920, 2200,
];
const resize = [];
for (const width of widths) {
  await page.setViewportSize({ width, height: 900 });
  const info = await fits();
  resize.push(info);
  assert(
    info.scrollWidth <= width,
    `Overflow at ${width}: ${JSON.stringify(info)}`,
  );
}
check("Continuous resize sweep has no horizontal page overflow", resize);
for (const [name, width, height] of [
  ["phone", 390, 844],
  ["ipad", 768, 1024],
  ["desktop", 1440, 1000],
]) {
  await page.setViewportSize({ width, height });
  await load();
  await page.evaluate(() => {
    document.querySelector("h1").innerHTML =
      "Make every thoughtful design decision work together, beautifully.";
    document.querySelector(".feature-copy h3").textContent =
      "An unmistakable voice, with clarity in every considered detail.";
    document.querySelector(".specimen h3").textContent =
      "A much longer headline for a changing world.";
    document.querySelector(".start-copy h2").textContent =
      "Your next big idea, more carefully considered.";
    document.querySelector(".hero-copy>p:not(.eyebrow)").textContent +=
      " Try longer content in another context, and let the relationships adapt to the available space.";
  });
  const fit = await fits();
  assert(
    fit.scrollWidth <= width,
    `${name} changed text overflow ${JSON.stringify(fit)}`,
  );
  await shot(name + "-changed-text", true);
  check(name + " longer content reflows", fit);
}
for (const [name, width, height] of [
  ["phone", 390, 844],
  ["ipad", 768, 1024],
  ["desktop", 1440, 1000],
]) {
  await page.setViewportSize({ width, height });
  await load();
  await page.evaluate(() => {
    const elements = [
      ...document.querySelectorAll("h1,h2,h3,h4,p,a,button,code,span"),
    ].filter(
      (el) =>
        el.textContent.trim() &&
        !el.closest('[aria-hidden="true"]') &&
        !el.closest(".aa"),
    );
    const sizes = elements.map((el) =>
      parseFloat(getComputedStyle(el).fontSize),
    );
    elements.forEach((el, i) => (el.style.fontSize = `${sizes[i] * 2}px`));
  });
  const fit = await fits();
  assert(
    fit.scrollWidth <= width,
    `${name} 200% text overflow ${JSON.stringify(fit)}`,
  );
  await shot(name + "-text-200", true);
  check(name + " 200% text enlargement reflows", fit);
}
await page.setViewportSize({ width: 1440, height: 1000 });
await load();
const contrastPairs = await page.evaluate(() => {
  const selections = [
    ["Primary CTA", ".hero-actions>a:first-child"],
    ["Body text", ".hero-copy>p:not(.eyebrow)"],
    ["Type specimen label", ".spec-label"],
    ["CTA body", ".start-copy>p:not(.eyebrow)"],
    ["Copy status", ".copy-status"],
    ["Footer note", ".footer-bottom>p"],
  ];
  return selections.map(([name, selector]) => {
    const el = document.querySelector(selector);
    let parent = el;
    let bg;
    while (parent) {
      bg = getComputedStyle(parent).backgroundColor;
      if (bg !== "rgba(0, 0, 0, 0)") break;
      parent = parent.parentElement;
    }
    return { name, foreground: getComputedStyle(el).color, background: bg };
  });
});
const ratios = contrastPairs.map((p) => ({
  ...p,
  ratio: new Color(p.foreground).contrast(new Color(p.background), "WCAG21"),
}));
assert(ratios.every((p) => p.ratio >= 4.5));
check("Sampled solid-surface small-text contrast at least 4.5:1", ratios);
const demoContrasts = [];
for (const label of ['Quiet','Balanced','Expressive']) {
 await page.locator('.direction-options button').filter({hasText:label}).click();
 const pair = await page.locator('.specimen').evaluate(el => ({foreground:getComputedStyle(el).color,background:getComputedStyle(el).backgroundColor}));
 const ratio = new Color(pair.foreground).contrast(new Color(pair.background),'WCAG21');
 assert(ratio >= 4.5); demoContrasts.push({label,...pair,ratio});
}
check('All three illustrative specimen palettes have text contrast at least 4.5:1',demoContrasts);
await context.close();
await browser.close();
const touchBrowser = await chromium.launch();
const touch = await touchBrowser.newContext({
  viewport: { width: 390, height: 844 },
  isMobile: true,
  hasTouch: true,
});
const tp = await touch.newPage();
await tp.goto("http://localhost:4173");
await tp.getByRole("button", { name: "Menu" }).tap();
await tp.getByRole("navigation").getByRole("link", { name: "Features" }).tap();
assert.equal(await tp.evaluate(() => location.hash), "#features");
await tp
  .locator(".direction-options button")
  .filter({ hasText: "Expressive" })
  .tap();
assert.match(await tp.locator(".specimen h3").textContent(), /Make some/);
check("Emulated touch menu and specimen controls");
await touchBrowser.close();
try {
  const b = await webkit.launch();
  for (const [name, width, height] of [
    ["desktop", 1440, 1000],
    ["ipad", 768, 1024],
    ["phone", 390, 844],
  ]) {
    const p = await b.newPage({
      viewport: { width, height },
      reducedMotion: "reduce",
    });
    p.on("pageerror", (e) => receipt.errors.push("WebKit: " + e.message));
    await p.goto("http://localhost:4173");
    await p.evaluate(() => document.fonts.ready);
    const fit = await p.evaluate(() => ({
      width: innerWidth,
      scrollWidth: document.documentElement.scrollWidth,
    }));
    assert.equal(fit.width, fit.scrollWidth);
    await p
      .locator(".direction-options button")
      .filter({ hasText: "Quiet" })
      .click();
    assert.match(await p.locator(".specimen h3").textContent(), /Space to/);
    await p.evaluate(() => scrollTo(0, 0));
    await p.screenshot({ path: `receipts/webkit-${name}.png`, fullPage: true });
    receipt.screenshots.push(`webkit-${name}.png`);
    check("WebKit " + name + " layout and specimen interaction", fit);
    await p.close();
  }
  await b.close();
} catch (e) {
  receipt.errors.push("WebKit: " + e.message);
}
assert.equal(receipt.errors.length, 0, JSON.stringify(receipt.errors));
check("No browser runtime errors or failed local requests");
receipt.notes.push(
  "Screenshots and checks use browser emulation, not physical devices.",
  "Repository link destinations were checked without browsing external sites.",
  "Changed-text and 200% text tests modify only the in-memory DOM.",
);
await writeFile(
  "receipts/checks.json",
  JSON.stringify(receipt, null, 2) + "\n",
);
