# Design Theory — build report

Completed November 8, 2026 (America/Detroit). Final output: `public/index.html`.

## Delivered

A complete single-page React + StyleX marketing site following the supplied brief, direction, content, and guidance. The composition uses warm paper, dark olive ink, vermilion, bundled variable/spectral typography, and the original supplied sculpture artwork. Layout uses flexbox; there is no CSS grid.

The journey covers the promise, typography/color/layout capabilities, an interactive relationship specimen, motion/materials/revisitable decisions, the four-step workflow, tooling details, and a source-checkout invitation. The evidence boundary is visible in the footer. No fabricated adoption, performance, aesthetic, signup, or package-install claims were added.

The specimen links type weight, leading, tracking, surface color, and transition duration. Presets, a native range input, reset, and local save/restore work. Its values are explicitly illustrative. The get-started command is `npm run build`, identified as a command for a configured source checkout; clipboard success and failure have visible live feedback. Repository CTAs use the exact approved GitHub URL.

Native scrolling drives campaign parallax and a middle-page composition of ring, sphere, and orbital line. Controls stay stationary. Reduced motion removes spatial parallax and transitions while preserving content and controls. Animation work runs on demand for visible scenes, stops when the document is hidden, and cleans up on unmount.

## Build and reproduce

```sh
npm run build
node src/finalize.mjs
python3 -m http.server 4173 --directory public
```

The supplied `npm run build` succeeded. The optional finalizer adds the static page title, description, theme color, code-native favicon, and a no-JavaScript repository fallback to the generated HTML. The application also sets its title and description at runtime. Serve the complete `public/` directory over HTTP.

Supplied inputs, `package.json`, `build.mjs`, assets, and dependencies were not edited. All nine deployed asset files match their supplied originals by SHA-256, including font licenses. Final file hashes are in [build-receipt.json](src/checks/build-receipt.json).

## Actual verification

Final automated verification: **23 checks passed, zero unresolved test failures** across the three check scripts below. Browser versions: Chromium 156.0.8078.4 and Playwright WebKit 27.2. These are desktop browser runs with viewport/touch emulation, not physical-device tests.

| Area | Performed check and outcome |
| --- | --- |
| Phone, iPad, desktop | Rendered and captured 390×844, 820×1180, and 1440×1000 in Chromium and WebKit. No runtime errors or meaningful content/control boxes outside the viewport in final checks. Inspected the page imagery, hierarchy, crops, and section flow. |
| Continuous resizing | 116 incremental viewport widths from 250 to 1745 pixels, plus 22 widths from 200 through 1920, including breakpoint neighbors. All tested text and control geometry passed. These samples are checks, not configured viewport limits. |
| Changed text and enlargement | Replaced the hero and get-started headings with longer copy, extended feature prose, and explicitly doubled rendered text sizes. Verified geometry and captured full pages at phone, iPad, and desktop widths. This was a CSS text-enlargement test, not an OS accessibility setting or physical browser-zoom test. |
| Keyboard | Skip link, visible focus, sequential tab navigation, anchor activation, Page Down, range Home/End/Arrow Right. Range endpoints 0/100 and step change passed. |
| Pointer | Preset changes, continuous slider drag, save/reset, copy, anchors, wheel scrolling, and interruption by keyboard/resize. Coupled computed type and color values changed as expected. |
| Touch emulation | Explicit touchscreen taps in Chromium and WebKit: presets, range track (result 24), save/reset, and get-started anchor. Copy control remained scroll-reachable at 390×300, 820×500, and 1440×400. |
| Local persistence | Save, reload, restore, reset, and simulated storage rejection. Each produced the intended state and visible status. |
| Clipboard | Real Chromium browser clipboard readback exactly matched `npm run build`. An injected rejected clipboard call produced the visible failure message and left the command selectable. |
| Motion | Captured three distinct middle-page frames and measured changing campaign/ring transforms. Interruption and resize preserved access and layout. |
| Reduced motion | Live media-preference switch removed ring/sphere parallax and transitions. Campaign transform stayed constant through scrolling. Presets remained usable. |
| Lifecycle | No growing RAF count while idle; offscreen scene values stayed unchanged; simulated hidden-document state suspended updates. Actual React unmount removed all four tracked event subscriptions and disconnected the observer. |
| Contrast | WCAG contrast calculations: body 13.68:1; muted paper text 5.31:1; dark-section secondary text 7.69:1; ink on vermilion 4.97:1; step numbers 5.29:1; specimen text on ring 4.50:1. Image labels use opaque ink backing, 14.53:1. This is scoped color verification, not an exhaustive accessibility audit. |
| Assets and links | Sculpture and all three used local fonts loaded. Artwork has descriptive alt text; decorative diagrams are hidden from assistive technology. Repository hrefs match the approved URL. Deployed asset hashes match originals. |

Initial checks exposed unsupported StyleX border shorthands and narrow/enlarged-content wrapping problems. These were corrected with explicit border properties, wrapping controls, and content-responsive flex sizing. Initial WebKit assertions also needed to await restored React state; the final interaction checks pass.

Receipts and reproducible checks:

- [Main browser checks](src/checks/verify.mjs) · [results](src/checks/results.json)
- [Lifecycle, resize, contrast, asset checks](src/checks/lifecycle.mjs) · [results](src/checks/lifecycle-results.json)
- [Touch and short-height checks](src/checks/touch.mjs) · [results](src/checks/touch-results.json)
- [Visual capture script](src/checks/inspect.mjs) · [screenshots](src/checks/screenshots/)

## Limits and unresolved failures

No known blocking implementation failure remains in the performed checks. Physical phones/iPads, shipping Safari, Firefox, manual screen-reader use, OS text settings, and older browser versions were not verified. Hidden-document behavior was simulated with a `document.hidden` override and visibility event. WebKit clipboard OS readback was not tested; actual clipboard success was verified in Chromium and the failure path was injected. External repository availability was not fetched; its URL was checked locally. The underlying Design Theory toolkit, selector, native mappings, and product research claims were not executed or validated by this marketing build.

## Assistance and study boundary

Implemented independently by this coding assistant using supplied local material, React, StyleX, local shell/build tools, Playwright, and colorjs.io for contrast calculations. No child agents, other builder models, model selector calls, web research, external inference, package/asset downloads, or new generated image assets were used. Original diagrams are CSS/SVG code. Chromium initially required an execution-sandbox exception to launch; authorized local browser verification then completed successfully.
