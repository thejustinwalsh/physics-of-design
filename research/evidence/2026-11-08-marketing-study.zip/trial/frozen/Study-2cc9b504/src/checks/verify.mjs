import { chromium, webkit } from "playwright";
import { mkdir, writeFile } from "node:fs/promises";
import assert from "node:assert/strict";
await mkdir("src/checks/screenshots", { recursive: true });
const result = {
  date: new Date().toISOString(),
  checks: [],
  failures: [],
  engines: [],
};
const report = (name, detail) => {
  result.checks.push({ name, detail });
  console.log("PASS", name, JSON.stringify(detail ?? ""));
};
const check = async (name, fn) => {
  try {
    await fn();
  } catch (e) {
    result.failures.push({ name, error: e.message });
    console.log("FAIL", name, e.message);
  }
};
const geometry = () => {
  const bad = [];
  const targets = [
    ...document.querySelectorAll("h1,h2,h3,p,nav a,button,label,code,footer a"),
  ];
  for (const e of targets) {
    const r = e.getBoundingClientRect();
    const text = e.textContent.trim();
    if (r.width < 1 || r.height < 1)
      bad.push({ text: text.slice(0, 60), reason: "zero size" });
    if (r.left < -0.5 || r.right > innerWidth + 0.5)
      bad.push({
        text: text.slice(0, 60),
        reason: "outside viewport",
        left: r.left,
        right: r.right,
      });
    if (
      e.scrollWidth > e.clientWidth + 2 &&
      getComputedStyle(e).display !== "inline"
    )
      bad.push({
        text: text.slice(0, 60),
        reason: "content wider than box",
        width: e.clientWidth,
        scroll: e.scrollWidth,
      });
  }
  return {
    width: innerWidth,
    scrollWidth: document.documentElement.scrollWidth,
    bad,
  };
};
const open = async (
  browser,
  viewport = { width: 1440, height: 1000 },
  options = {},
) => {
  const page = await browser.newPage({ viewport, ...options });
  const errors = [];
  page.on("pageerror", (e) => errors.push(e.message));
  page.on("console", (msg) => {
    if (msg.type() === "error") errors.push(msg.text());
  });
  await page.goto("http://localhost:4173");
  await page.evaluate(() => document.fonts.ready);
  await page.waitForTimeout(100);
  return { page, errors };
};
const browser = await chromium.launch();
result.engines.push({ engine: "Chromium", version: browser.version() });
let { page, errors } = await open(browser);
await check("Responsive width sweep", async () => {
  const issues = [];
  const sizes = [
    200, 240, 280, 320, 350, 390, 600, 601, 700, 701, 768, 800, 801, 820, 900,
    901, 1024, 1100, 1280, 1440, 1680, 1920,
  ];
  for (const width of sizes) {
    await page.setViewportSize({ width, height: 900 });
    const g = await page.evaluate(geometry);
    if (g.bad.length || g.scrollWidth > width) issues.push(g);
  }
  result.responsiveIssues = issues;
  assert.equal(issues.length, 0, JSON.stringify(issues));
  report("Responsive width sweep", sizes);
});
await page.setViewportSize({ width: 1440, height: 1000 });
await check("Keyboard skip link and navigation anchors", async () => {
  await page.goto("http://localhost:4173");
  await page.keyboard.press("Tab");
  assert.equal(await page.locator(":focus").textContent(), "Skip to content");
  await page.keyboard.press("Enter");
  assert.equal(await page.evaluate(() => location.hash), "#main");
  await page.goto("http://localhost:4173");
  const trail = [];
  for (let i = 0; i < 8; i++) {
    await page.keyboard.press("Tab");
    trail.push(
      await page
        .locator(":focus")
        .evaluate((e) => ({
          tag: e.tagName,
          text: e.textContent.trim(),
          outline: getComputedStyle(e).outlineStyle,
        })),
    );
  }
  assert(trail.some((e) => e.text === "Features"));
  assert(trail.every((e) => e.outline !== "none"));
  for (const [name, id] of [
    ["Features", "features"],
    ["How it works", "how-it-works"],
    ["Get started", "get-started"],
  ]) {
    await page
      .getByRole("navigation")
      .getByRole("link", { name, exact: true })
      .click();
    await page.waitForTimeout(700);
    assert.equal(await page.evaluate(() => location.hash), "#" + id);
    const y = await page
      .locator("#" + id)
      .evaluate((e) => e.getBoundingClientRect().top);
    assert(y >= 0 && y < 500, `${name} anchor top ${y}`);
  }
  report("Keyboard skip link and navigation anchors", trail);
});
await check("Presets, continuous pointer and keyboard range", async () => {
  await page.getByRole("button", { name: "Quiet", exact: true }).click();
  assert.equal(await page.locator("#expression").inputValue(), "12");
  await page.waitForTimeout(800);
  const quiet = await page
    .locator(".specimen-title")
    .evaluate((e) => ({
      weight: getComputedStyle(e).fontWeight,
      leading: getComputedStyle(e).lineHeight,
      spacing: getComputedStyle(e).letterSpacing,
      background: getComputedStyle(e.parentElement).backgroundColor,
    }));
  await page.getByRole("button", { name: "Expressive", exact: true }).click();
  await page.waitForTimeout(500);
  const expressive = await page
    .locator(".specimen-title")
    .evaluate((e) => ({
      weight: getComputedStyle(e).fontWeight,
      leading: getComputedStyle(e).lineHeight,
      spacing: getComputedStyle(e).letterSpacing,
      background: getComputedStyle(e.parentElement).backgroundColor,
    }));
  assert.notEqual(quiet.weight, expressive.weight);
  assert.notEqual(quiet.leading, expressive.leading);
  assert.notEqual(quiet.spacing, expressive.spacing);
  assert.notEqual(quiet.background, expressive.background);
  const slider = page.locator("#expression");
  await slider.scrollIntoViewIfNeeded();
  const box = await slider.boundingBox();
  await page.mouse.move(box.x + box.width * 0.3, box.y + box.height / 2);
  await page.mouse.down();
  for (let i = 3; i < 9; i++) {
    await page.mouse.move(
      box.x + (box.width * i) / 10,
      box.y + box.height / 2,
      { steps: 3 },
    );
  }
  await page.mouse.up();
  const dragged = Number(await slider.inputValue());
  assert(dragged > 65 && dragged < 95);
  await slider.focus();
  await page.keyboard.press("Home");
  assert.equal(await slider.inputValue(), "0");
  await page.keyboard.press("ArrowRight");
  assert.equal(await slider.inputValue(), "1");
  await page.keyboard.press("End");
  assert.equal(await slider.inputValue(), "100");
  await page.screenshot({
    path: "src/checks/screenshots/desktop-expression-100.png",
  });
  report("Presets, continuous pointer and keyboard range", {
    quiet,
    expressive,
    dragged,
    endpoints: [0, 1, 100],
  });
});
await check("Save and restore direction", async () => {
  await page.getByRole("button", { name: "Keep this direction" }).click();
  assert.match(
    await page.locator("[role=status]").first().textContent(),
    /Direction saved/,
  );
  await page.reload();
  assert.equal(await page.locator("#expression").inputValue(), "100");
  assert.match(
    await page.locator("[role=status]").first().textContent(),
    /restored/,
  );
  await page.getByRole("button", { name: "Reset", exact: true }).click();
  assert.equal(await page.locator("#expression").inputValue(), "46");
  report("Save and restore direction", { storedExpression: 100, reset: 46 });
});
await check("Real clipboard command and feedback", async () => {
  await page.context().grantPermissions(["clipboard-read", "clipboard-write"]);
  await page.getByRole("button", { name: "Copy command", exact: true }).click();
  assert.equal(
    await page.evaluate(() => navigator.clipboard.readText()),
    "npm run build",
  );
  assert.match(
    await page.locator("[role=status]").last().textContent(),
    /Copied!/,
  );
  report(
    "Real clipboard command and feedback",
    "OS browser clipboard contains npm run build",
  );
});
await check("Clipboard rejection feedback", async () => {
  await page.evaluate(() => {
    Object.defineProperty(navigator.clipboard, "writeText", {
      configurable: true,
      value: () => Promise.reject(new Error("denied in verification")),
    });
  });
  await page.getByRole("button", { name: "Copy command", exact: true }).click();
  assert.match(
    await page.locator("[role=status]").last().textContent(),
    /Could not copy/,
  );
  report(
    "Clipboard rejection feedback",
    "Visible selectable command and failure status",
  );
});
await check("Storage failure feedback", async () => {
  await page.evaluate(() => {
    Storage.prototype.setItem = () => {
      throw new Error("denied in verification");
    };
  });
  await page.getByRole("button", { name: "Keep this direction" }).click();
  assert.match(
    await page.locator("[role=status]").first().textContent(),
    /Could not save/,
  );
  report(
    "Storage failure feedback",
    "Browser storage rejection produces visible status",
  );
});
await check("Scroll frames and interruption", async () => {
  await page.reload();
  await page.evaluate(() => {
    document.documentElement.style.scrollBehavior = "auto";
  });
  const campaign = [];
  for (const y of [0, 250, 500]) {
    await page.evaluate((y) => scrollTo(0, y), y);
    await page.waitForTimeout(120);
    campaign.push(
      await page
        .locator(".campaign-image")
        .evaluate((e) => getComputedStyle(e).transform),
    );
  }
  assert(new Set(campaign).size > 1);
  const frames = [];
  const top = await page
    .locator(".specimen")
    .evaluate((e) => e.getBoundingClientRect().top + scrollY);
  for (const [i, y] of [top - 850, top - 500, top - 150].entries()) {
    await page.evaluate((y) => scrollTo(0, y), y);
    await page.waitForTimeout(650);
    frames.push(
      await page
        .locator(".specimen-ring")
        .evaluate((e) => getComputedStyle(e).transform),
    );
    await page.screenshot({
      path: `src/checks/screenshots/scroll-frame-${i}.png`,
    });
  }
  assert.equal(new Set(frames).size, 3);
  await page.mouse.wheel(0, -300);
  await page.waitForTimeout(150);
  await page.keyboard.press("PageDown");
  await page.waitForTimeout(250);
  await page.setViewportSize({ width: 980, height: 700 });
  await page.waitForTimeout(200);
  assert((await page.evaluate(geometry)).bad.length === 0);
  report("Scroll frames and interruption", { campaign, frames });
});
await check(
  "Reduced motion retains controls and removes parallax",
  async () => {
    await page.emulateMedia({ reducedMotion: "reduce" });
    await page.setViewportSize({ width: 390, height: 844 });
    const values = [];
    for (const y of [0, 450, 2600]) {
      await page.evaluate((y) => scrollTo(0, y), y);
      await page.waitForTimeout(100);
      values.push(
        await page.evaluate(() => ({
          campaign: getComputedStyle(document.querySelector(".campaign-image"))
            .transform,
          ring: getComputedStyle(document.querySelector(".specimen-ring"))
            .transform,
          sphere: getComputedStyle(document.querySelector(".specimen-sphere"))
            .transform,
          transition: getComputedStyle(
            document.querySelector(".specimen-title"),
          ).transitionDuration,
        })),
      );
    }
    assert.equal(new Set(values.map((v) => v.campaign)).size, 1);
    assert(
      values.every(
        (v) =>
          v.ring === "none" && v.sphere === "none" && v.transition === "0s",
      ),
    );
    await page.getByRole("button", { name: "Quiet", exact: true }).click();
    assert.equal(await page.locator("#expression").inputValue(), "12");
    await page.getByRole("button", { name: "Expressive", exact: true }).click();
    assert.equal(await page.locator("#expression").inputValue(), "90");
    await page.screenshot({
      path: "src/checks/screenshots/phone-reduced-motion.png",
    });
    report("Reduced motion retains controls and removes parallax", values);
  },
);
await check("Changed text and 200 percent text enlargement", async () => {
  await page.goto("http://localhost:4173");
  await page.evaluate(() => document.fonts.ready);
  await page.evaluate(() => {
    document.querySelector("h1").textContent =
      "Make every thoughtful design decision work beautifully together.";
    document.querySelector("#get-started h2").textContent =
      "Start with your next ambitious project. Keep your own point of view.";
    document
      .querySelectorAll("article p")
      .forEach(
        (e) =>
          (e.textContent +=
            " Revisit the details when the content changes, at every size and in every context."),
      );
    document
      .querySelectorAll("h1,h2,h3,p,a,button,label,code,span")
      .forEach((e) => {
        if (!e.children.length || /H[123]|P/.test(e.tagName))
          e.dataset.originalFont = getComputedStyle(e).fontSize;
      });
    document
      .querySelectorAll("[data-original-font]")
      .forEach(
        (e) =>
          (e.style.fontSize = parseFloat(e.dataset.originalFont) * 2 + "px"),
      );
  });
  const issues = [];
  for (const [name, width, height] of [
    ["phone", 390, 844],
    ["ipad", 820, 1180],
    ["desktop", 1440, 1000],
  ]) {
    await page.setViewportSize({ width, height });
    const g = await page.evaluate(geometry);
    if (g.bad.length) issues.push(g);
    await page.screenshot({
      path: `src/checks/screenshots/${name}-text-stress.png`,
      fullPage: true,
    });
  }
  result.textStressIssues = issues;
  assert.equal(issues.length, 0, JSON.stringify(issues));
  report(
    "Changed text and 200 percent text enlargement",
    "Longer headlines and feature prose; explicit doubling of rendered text font sizes at 390/820/1440",
  );
});
report("Chromium runtime errors", errors);
await page.close();
await browser.close();
const wk = await webkit.launch();
result.engines.push({ engine: "WebKit", version: wk.version() });
for (const [name, width, height, options] of [
  ["desktop", 1440, 1000, {}],
  ["ipad", 820, 1180, { hasTouch: true, isMobile: true }],
  ["phone", 390, 844, { hasTouch: true, isMobile: true }],
]) {
  await check(`WebKit ${name}`, async () => {
    const { page: p, errors: e } = await open(wk, { width, height }, options);
    const g = await p.evaluate(geometry);
    assert.equal(g.bad.length, 0, JSON.stringify(g));
    await p.getByRole("button", { name: "Expressive", exact: true }).click();
    await p.waitForFunction(
      () => document.querySelector("#expression").value === "90",
    );
    assert.equal(await p.locator("#expression").inputValue(), "90");
    await p.getByRole("button", { name: "Keep this direction" }).click();
    await p.reload();
    await p.waitForFunction(
      () => document.querySelector("#expression").value === "90",
    );
    assert.equal(await p.locator("#expression").inputValue(), "90");
    await p.getByRole("button", { name: "Reset", exact: true }).click();
    await p.screenshot({
      path: `src/checks/screenshots/webkit-${name}-full.png`,
      fullPage: true,
    });
    assert.equal(e.length, 0, JSON.stringify(e));
    report(`WebKit ${name}`, {
      viewport: { width, height },
      geometry: g,
      errors: e,
      touch: options.hasTouch ?? false,
    });
    await p.close();
  });
}
await wk.close();
await writeFile("src/checks/results.json", JSON.stringify(result, null, 2));
console.log(
  `Completed: ${result.checks.length} checks; ${result.failures.length} failures`,
);
if (result.failures.length) process.exitCode = 1;
