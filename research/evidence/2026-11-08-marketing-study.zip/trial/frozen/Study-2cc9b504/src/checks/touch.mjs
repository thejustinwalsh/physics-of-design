import { chromium, webkit } from "playwright";
import { writeFile } from "node:fs/promises";
import assert from "node:assert/strict";
const result = { checks: [], failures: [] };
for (const engine of [chromium, webkit]) {
  const browser = await engine.launch();
  const page = await browser.newPage({
    viewport: { width: 390, height: 844 },
    isMobile: true,
    hasTouch: true,
  });
  try {
    await page.goto("http://localhost:4173");
    await page.evaluate(() => document.fonts.ready);
    await page.getByRole("button", { name: "Quiet", exact: true }).tap();
    await page.waitForFunction(
      () => document.querySelector("#expression").value === "12",
    );
    await page.getByRole("button", { name: "Expressive", exact: true }).tap();
    await page.waitForFunction(
      () => document.querySelector("#expression").value === "90",
    );
    const slider = page.locator("#expression");
    await slider.scrollIntoViewIfNeeded();
    const r = await slider.boundingBox();
    await page.touchscreen.tap(r.x + r.width * 0.25, r.y + r.height / 2);
    await page.waitForTimeout(150);
    const value = Number(await slider.inputValue());
    assert(value > 15 && value < 35);
    await page.getByRole("button", { name: "Keep this direction" }).tap();
    await page.waitForFunction(() =>
      document
        .querySelector("[role=status]")
        .textContent.includes("Direction saved"),
    );
    await page.getByRole("button", { name: "Reset", exact: true }).tap();
    await page.waitForFunction(
      () => document.querySelector("#expression").value === "46",
    );
    await page
      .getByRole("navigation")
      .getByRole("link", { name: "Get started", exact: true })
      .tap();
    await page.waitForTimeout(750);
    assert.equal(await page.evaluate(() => location.hash), "#get-started");
    await page.screenshot({
      path: `src/checks/screenshots/${engine.name()}-phone-start.png`,
    });
    for (const [width, height] of [
      [390, 300],
      [820, 500],
      [1440, 400],
    ]) {
      await page.setViewportSize({ width, height });
      await page
        .getByRole("button", { name: "Copy command", exact: true })
        .scrollIntoViewIfNeeded();
      const b = await page
        .getByRole("button", { name: "Copy command", exact: true })
        .boundingBox();
      assert(b.y >= 0 && b.y + b.height <= height + 1);
    }
    const detail = {
      engine: engine.name(),
      version: browser.version(),
      touchPresets: [12, 90],
      touchRange: value,
      savedAndReset: true,
      anchor: true,
      shortViewports: [
        [390, 300],
        [820, 500],
        [1440, 400],
      ],
    };
    result.checks.push(detail);
    console.log("PASS", JSON.stringify(detail));
  } catch (e) {
    result.failures.push({ engine: engine.name(), error: e.message });
    console.log("FAIL", engine.name(), e.message);
  }
  await browser.close();
}
await writeFile(
  "src/checks/touch-results.json",
  JSON.stringify(result, null, 2),
);
if (result.failures.length) process.exitCode = 1;
