import { chromium } from "playwright";
import Color from "colorjs.io";
import assert from "node:assert/strict";
import { writeFile } from "node:fs/promises";
const result = { checks: [], failures: [] };
const check = async (name, fn) => {
  try {
    const detail = await fn();
    result.checks.push({ name, detail });
    console.log("PASS", name, JSON.stringify(detail));
  } catch (e) {
    result.failures.push({ name, error: e.message });
    console.log("FAIL", name, e.message);
  }
};
const browser = await chromium.launch();
const page = await browser.newPage({ viewport: { width: 1440, height: 1000 } });
await page.addInitScript(() => {
  window.receipt = {
    add: [],
    remove: [],
    observed: 0,
    disconnected: 0,
    raf: 0,
  };
  const add = EventTarget.prototype.addEventListener,
    remove = EventTarget.prototype.removeEventListener;
  const tracked = (t, k) =>
    (t === window && ["scroll", "resize"].includes(k)) ||
    (t === document && k === "visibilitychange") ||
    (t instanceof MediaQueryList && k === "change");
  EventTarget.prototype.addEventListener = function (k, fn, ...rest) {
    if (tracked(this, k)) receipt.add.push({ k, fn, t: this });
    return add.call(this, k, fn, ...rest);
  };
  EventTarget.prototype.removeEventListener = function (k, fn, ...rest) {
    if (tracked(this, k)) receipt.remove.push({ k, fn, t: this });
    return remove.call(this, k, fn, ...rest);
  };
  const IO = IntersectionObserver;
  window.IntersectionObserver = class extends IO {
    observe(...a) {
      receipt.observed++;
      super.observe(...a);
    }
    disconnect() {
      receipt.disconnected++;
      super.disconnect();
    }
  };
  const raf = requestAnimationFrame;
  window.requestAnimationFrame = (fn) => {
    receipt.raf++;
    return raf(fn);
  };
});
await page.goto("http://localhost:4173");
await page.evaluate(() => document.fonts.ready);
await page.waitForTimeout(150);
await check("No idle animation loop", async () => {
  const a = await page.evaluate(() => receipt.raf);
  await page.waitForTimeout(400);
  const b = await page.evaluate(() => receipt.raf);
  assert.equal(a, b);
  return { rafBefore: a, rafAfter: b };
});
await check("Offscreen scenes stay unchanged", async () => {
  await page.evaluate(() => {
    document.documentElement.style.scrollBehavior = "auto";
    scrollTo(0, document.body.scrollHeight);
  });
  await page.waitForTimeout(100);
  const a = await page
    .locator("[data-scene]")
    .evaluateAll((els) =>
      els.map((e) => e.style.getPropertyValue("--progress")),
    );
  await page.mouse.wheel(0, -50);
  await page.waitForTimeout(100);
  const b = await page
    .locator("[data-scene]")
    .evaluateAll((els) =>
      els.map((e) => e.style.getPropertyValue("--progress")),
    );
  assert.deepEqual(a, b);
  return { before: a, after: b };
});
await check("Hidden document suspends scene updates", async () => {
  await page.evaluate(() => {
    scrollTo(0, 300);
  });
  await page.waitForTimeout(100);
  const a = await page
    .locator("[data-scene]")
    .evaluateAll((els) =>
      els.map((e) => e.style.getPropertyValue("--progress")),
    );
  await page.evaluate(() => {
    Object.defineProperty(document, "hidden", {
      configurable: true,
      get: () => true,
    });
    document.dispatchEvent(new Event("visibilitychange"));
    scrollTo(0, 500);
  });
  await page.waitForTimeout(150);
  const b = await page
    .locator("[data-scene]")
    .evaluateAll((els) =>
      els.map((e) => e.style.getPropertyValue("--progress")),
    );
  assert.deepEqual(a, b);
  await page.evaluate(() => {
    delete document.hidden;
    document.dispatchEvent(new Event("visibilitychange"));
  });
  return {
    simulation: "document.hidden override plus visibilitychange",
    before: a,
    after: b,
  };
});
await check("Continuous window resizing", async () => {
  let samples = 0;
  for (let width = 250; width <= 1750; width += 13) {
    await page.setViewportSize({ width, height: 880 });
    const issue = await page.evaluate(() => {
      const els = [
        ...document.querySelectorAll("h1,h2,h3,p,nav a,button,label,code"),
      ];
      return els
        .map((e) => ({
          text: e.textContent.slice(0, 40),
          r: e.getBoundingClientRect(),
        }))
        .filter(({ r }) => r.left < -0.5 || r.right > innerWidth + 0.5)
        .map(({ text, r }) => ({ text, left: r.left, right: r.right }));
    });
    assert.equal(issue.length, 0, `width ${width}: ${JSON.stringify(issue)}`);
    samples++;
  }
  return { from: 250, to: 1745, step: 13, samples };
});
await check("Repository URLs and local asset integrity", async () => {
  const data = await page.evaluate(() => ({
    repo: [...document.querySelectorAll('a[href^="https:"]')].map(
      (e) => e.href,
    ),
    images: [...document.images].map((e) => ({
      loaded: e.complete && e.naturalWidth > 0,
      alt: e.alt,
      width: e.naturalWidth,
    })),
    fonts: [...document.fonts].map((f) => ({
      family: f.family,
      status: f.status,
    })),
    title: document.title,
  }));
  assert(
    data.repo.every(
      (x) => x === "https://github.com/thejustinwalsh/physics-of-design",
    ),
  );
  assert(data.images.every((x) => x.loaded && x.alt));
  assert(data.fonts.every((x) => x.status === "loaded"));
  return data;
});
await check("Scoped text contrast", async () => {
  const pairs = [
    ["body", "#23261f", "#f4f2e9"],
    ["muted", "#62655a", "#f4f2e9"],
    ["dark secondary", "#b9b8ad", "#23261f"],
    ["start section", "#23261f", "#ed6b49"],
    ["step numbers", "#ad4029", "#f4f2e9"],
    ["specimen on ring", "#21221e", "#dd6245"],
    ["art labels", "#fff8eb", "#23261f"],
  ];
  const ratios = pairs.map(([name, fg, bg]) => ({
    name,
    fg,
    bg,
    ratio: new Color(fg).contrast(new Color(bg), "WCAG21"),
  }));
  assert(ratios.every((r) => r.ratio >= 4.5));
  return ratios;
});
await check("Effect cleanup after React unmount", async () => {
  const data = await page.evaluate(async () => {
    const { appRoot } = await import("/app.js");
    appRoot.unmount();
    await new Promise((r) => setTimeout(r, 50));
    return {
      added: receipt.add.map((x) => x.k),
      removed: receipt.remove.map((x) => x.k),
      allRemoved: receipt.add.every((a) =>
        receipt.remove.some((b) => a.k === b.k && a.fn === b.fn && a.t === b.t),
      ),
      observed: receipt.observed,
      disconnected: receipt.disconnected,
      rootChildren: document.querySelector("#root").children.length,
    };
  });
  assert(data.allRemoved);
  assert.equal(data.observed, 2);
  assert.equal(data.disconnected, 1);
  assert.equal(data.rootChildren, 0);
  return data;
});
await browser.close();
await writeFile(
  "src/checks/lifecycle-results.json",
  JSON.stringify(result, null, 2),
);
if (result.failures.length) process.exitCode = 1;
