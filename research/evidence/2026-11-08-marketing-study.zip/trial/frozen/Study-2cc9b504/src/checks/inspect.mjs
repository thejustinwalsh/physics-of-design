import { chromium, webkit } from "playwright";
import { mkdir, writeFile } from "node:fs/promises";
await mkdir("src/checks/screenshots", { recursive: true });
const browser = await chromium.launch();
const receipts = [];
for (const [name, width, height] of [
  ["desktop", 1440, 1000],
  ["ipad", 820, 1180],
  ["phone", 390, 844],
]) {
  const page = await browser.newPage({
    viewport: { width, height },
    deviceScaleFactor: 1,
  });
  const errors = [];
  page.on("pageerror", (e) => errors.push(e.message));
  await page.goto("http://localhost:4173");
  await page.evaluate(() => document.fonts.ready);
  await page.waitForTimeout(200);
  await page.screenshot({
    path: `src/checks/screenshots/${name}-full.png`,
    fullPage: true,
  });
  await page.screenshot({ path: `src/checks/screenshots/${name}-hero.png` });
  receipts.push({
    name,
    width,
    height,
    errors,
    metrics: await page.evaluate(() => ({
      scrollWidth: document.documentElement.scrollWidth,
      width: innerWidth,
      height: document.documentElement.scrollHeight,
      heading: document.querySelector("h1").getBoundingClientRect().toJSON(),
      fonts: document.fonts.status,
    })),
  });
  await page.close();
}
console.log(JSON.stringify(receipts, null, 2));
await browser.close();
try {
  const w = await webkit.launch();
  console.log("WebKit available");
  await w.close();
} catch (e) {
  console.log("WebKit unavailable:", e.message);
}
await writeFile("src/checks/initial.json", JSON.stringify(receipts, null, 2));
