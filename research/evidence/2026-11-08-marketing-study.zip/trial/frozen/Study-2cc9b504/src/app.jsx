import React, { useEffect, useState } from "react";
import { createRoot } from "react-dom/client";
import * as stylex from "@stylexjs/stylex";

const REPO = "https://github.com/thejustinwalsh/physics-of-design";
const s = stylex.create({
  shell: { width: "100%" },
  wrap: {
    width: "100%",
    maxWidth: 1680,
    marginInline: "auto",
    paddingInline: {
      default: 48,
      "@media (max-width: 1000px)": 32,
      "@media (max-width: 600px)": 20,
    },
  },
  header: {
    display: "flex",
    flexWrap: "wrap",
    alignItems: "center",
    justifyContent: "space-between",
    gap: 24,
    paddingBlock: 27,
    borderBottomWidth: 1,
    borderBottomStyle: "solid",
    borderBottomColor: "var(--rule)",
  },
  brand: {
    display: "inline-flex",
    alignItems: "center",
    gap: 11,
    textDecoration: "none",
    fontSize: 21,
    fontWeight: 650,
    letterSpacing: "-0.8px",
    flexShrink: 0,
  },
  nav: {
    display: "flex",
    flexWrap: "wrap",
    alignItems: "center",
    gap: { default: 35, "@media (max-width: 600px)": 22 },
    fontSize: 13,
    "@media (max-width: 600px)": {
      width: "100%",
      justifyContent: "space-between",
    },
  },
  navLink: { textDecoration: "none", paddingBlock: 6 },
  navCta: {
    display: "inline-flex",
    alignItems: "center",
    justifyContent: "center",
    gap: 20,
    borderWidth: 1,
    borderStyle: "solid",
    borderColor: "var(--ink)",
    borderRadius: 40,
    padding: "11px 18px",
    textDecoration: "none",
  },
  heroTop: {
    display: "flex",
    alignItems: "flex-end",
    gap: 32,
    paddingTop: { default: 61, "@media (max-width: 600px)": 38 },
    paddingBottom: 46,
    "@media (max-width: 900px)": {
      flexDirection: "column",
      alignItems: "flex-start",
      gap: 26,
    },
  },
  heroTitle: {
    fontSize: {
      default: "clamp(70px, 7.65vw, 124px)",
      "@media (max-width: 900px)": "clamp(58px, 10.6vw, 94px)",
      "@media (max-width: 600px)": "clamp(44px, 12.6vw, 74px)",
    },
    fontWeight: 560,
    lineHeight: 0.99,
    letterSpacing: "-0.045em",
    margin: 0,
    flex: "1 1 0",
    minWidth: 0,
  },
  heroIntro: {
    flex: "0 0 24%",
    maxWidth: 340,
    paddingBottom: 7,
    "@media (max-width: 900px)": {
      display: "flex",
      maxWidth: "100%",
      gap: 36,
      alignItems: "center",
    },
    "@media (max-width: 600px)": { display: "block" },
  },
  intro: {
    fontSize: 16,
    lineHeight: 1.55,
    margin: "0 0 24px",
    "@media (min-width: 601px) and (max-width: 900px)": {
      margin: 0,
      maxWidth: 400,
    },
  },
  button: {
    display: "inline-flex",
    alignItems: "center",
    justifyContent: "center",
    gap: 24,
    backgroundColor: "var(--ink)",
    color: "var(--paper)",
    padding: "15px 21px",
    borderWidth: 1,
    borderStyle: "solid",
    borderColor: "var(--ink)",
    borderRadius: 3,
    textDecoration: "none",
    fontSize: 13,
    fontWeight: 550,
    cursor: "pointer",
    flexShrink: 0,
    minHeight: 48,
  },
  artwork: {
    position: "relative",
    height: {
      default: "clamp(420px, 43vw, 640px)",
      "@media (max-width: 600px)": 430,
    },
    overflow: "hidden",
    backgroundColor: "#d0b497",
    isolation: "isolate",
  },
  artImg: {
    width: "100%",
    height: "calc(100% + 110px)",
    position: "absolute",
    top: -55,
    left: 0,
    objectFit: "cover",
    objectPosition: "50% 56%",
    "@media (max-width: 600px)": { objectPosition: "43% 50%" },
  },
  artTop: {
    position: "absolute",
    left: 20,
    top: 20,
    padding: "9px 11px",
    backgroundColor: "#23261f",
    color: "#fff8eb",
    display: "flex",
    alignItems: "center",
    gap: 12,
    fontSize: 11,
    letterSpacing: "0.1em",
  },
  artBottom: {
    position: "absolute",
    bottom: 23,
    left: 26,
    right: 26,
    display: "flex",
    justifyContent: "space-between",
    alignItems: "flex-end",
    color: "#fff8eb",
    fontSize: 12,
    gap: 16,
  },
  artCaption: {
    maxWidth: 230,
    fontSize: 13,
    lineHeight: 1.4,
    padding: "9px 11px",
    backgroundColor: "#23261f",
  },
  artBadge: {
    backgroundColor: "#23261f",
    width: 57,
    height: 57,
    borderWidth: 1,
    borderStyle: "solid",
    borderColor: "#fff8eb90",
    borderRadius: "50%",
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
    flexShrink: 0,
  },
  imageMeta: {
    display: "flex",
    justifyContent: "space-between",
    flexWrap: "wrap",
    gap: 12,
    fontSize: 10,
    letterSpacing: "0.08em",
    textTransform: "uppercase",
    paddingBlock: 17,
    borderBottomWidth: 1,
    borderBottomStyle: "solid",
    borderBottomColor: "var(--rule)",
    color: "var(--muted)",
  },
  section: {
    paddingTop: { default: 116, "@media (max-width: 600px)": 76 },
    paddingBottom: { default: 112, "@media (max-width: 600px)": 72 },
  },
  eyebrow: {
    display: "flex",
    alignItems: "center",
    gap: 12,
    fontSize: 11,
    fontWeight: 550,
    letterSpacing: "0.12em",
    textTransform: "uppercase",
    margin: "0 0 30px",
  },
  sectionLead: {
    display: "flex",
    justifyContent: "space-between",
    gap: 50,
    alignItems: "flex-end",
    marginBottom: 64,
    "@media (max-width: 700px)": {
      flexDirection: "column",
      alignItems: "flex-start",
      gap: 24,
      marginBottom: 38,
    },
  },
  h2: {
    fontSize: {
      default: "clamp(48px, 5.5vw, 82px)",
      "@media (max-width: 600px)": "clamp(40px, 11vw, 62px)",
    },
    lineHeight: 1.02,
    letterSpacing: "-0.03em",
    fontWeight: 530,
    margin: 0,
    minWidth: 0,
  },
  leadP: { fontSize: 17, lineHeight: 1.65, maxWidth: 355, margin: 0 },
  featureRow: {
    display: "flex",
    gap: 32,
    "@media (max-width: 700px)": { flexDirection: "column", gap: 42 },
  },
  feature: {
    flex: "1 1 0",
    minWidth: 0,
    borderTopWidth: 1,
    borderTopStyle: "solid",
    borderTopColor: "var(--ink)",
    paddingTop: 17,
  },
  number: { fontSize: 11, fontFamily: "var(--mono)", color: "var(--muted)" },
  featureArt: {
    height: 200,
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
    position: "relative",
    marginBlock: 22,
    overflow: "hidden",
    backgroundColor: "#eae7df",
  },
  h3: {
    fontSize: 25,
    fontWeight: 550,
    lineHeight: 1.15,
    letterSpacing: "-0.03em",
    margin: "0 0 14px",
  },
  featureP: {
    fontSize: 14,
    lineHeight: 1.65,
    color: "var(--muted)",
    margin: 0,
    maxWidth: 390,
  },
  dark: {
    backgroundColor: "var(--ink)",
    color: "var(--paper)",
    position: "relative",
  },
  labIntro: {
    display: "flex",
    alignItems: "flex-start",
    justifyContent: "space-between",
    gap: 35,
    marginBottom: 55,
    "@media (max-width: 700px)": { flexDirection: "column", gap: 25 },
  },
  labAside: {
    maxWidth: 310,
    paddingTop: 9,
    fontSize: 15,
    lineHeight: 1.65,
    color: "#b9b8ad",
    margin: 0,
  },
  labLayout: {
    display: "flex",
    gap: { default: 70, "@media (max-width: 1000px)": 38 },
    alignItems: "center",
    "@media (max-width: 800px)": {
      flexDirection: "column",
      alignItems: "stretch",
    },
  },
  specimen: {
    flex: "1.5 1 0",
    minWidth: 0,
    position: "relative",
    overflow: "hidden",
    isolation: "isolate",
    padding: { default: 40, "@media (max-width: 600px)": 25 },
    backgroundColor: "#ede8da",
    color: "#21221e",
    minHeight: 500,
    display: "flex",
    flexDirection: "column",
    justifyContent: "space-between",
    "@media (max-width: 600px)": { minHeight: 460 },
  },
  specimenLabel: {
    display: "flex",
    justifyContent: "space-between",
    alignItems: "center",
    gap: 20,
    fontSize: 10,
    letterSpacing: "0.12em",
    borderBottomWidth: 1,
    borderBottomStyle: "solid",
    borderBottomColor: "#21221e45",
    paddingBottom: 17,
    position: "relative",
    zIndex: 2,
  },
  specimenTitle: {
    position: "relative",
    zIndex: 2,
    fontSize: {
      default: "clamp(58px, 6.1vw, 94px)",
      "@media (max-width: 800px)": "clamp(58px, 10vw, 96px)",
    },
    margin: "36px 0 24px",
    maxWidth: "80%",
    fontWeight: 500,
  },
  specimenBottom: {
    position: "relative",
    zIndex: 2,
    fontSize: 12,
    lineHeight: 1.55,
    maxWidth: 190,
    margin: 0,
  },
  controls: {
    flex: "1 1 0",
    minWidth: 0,
    maxWidth: 440,
    "@media (max-width: 800px)": { maxWidth: "none" },
  },
  controlTitle: {
    fontSize: 25,
    fontWeight: 500,
    letterSpacing: "-0.03em",
    margin: "0 0 13px",
  },
  controlP: {
    fontSize: 14,
    lineHeight: 1.65,
    color: "#b9b8ad",
    margin: "0 0 30px",
  },
  presets: { display: "flex", flexWrap: "wrap", gap: 8, marginBottom: 29 },
  preset: {
    borderWidth: 1,
    borderStyle: "solid",
    borderColor: "#66685d",
    borderRadius: 40,
    backgroundColor: "transparent",
    color: "var(--paper)",
    padding: "11px 17px",
    fontSize: 12,
    cursor: "pointer",
    minHeight: 42,
  },
  rangeLabels: {
    display: "flex",
    justifyContent: "space-between",
    gap: 12,
    fontSize: 11,
    marginBlock: "8px 16px",
    color: "#b9b8ad",
  },
  metricRow: {
    display: "flex",
    justifyContent: "space-between",
    gap: 16,
    borderTopWidth: 1,
    borderTopStyle: "solid",
    borderTopColor: "#ffffff26",
    paddingBlock: 13,
    fontSize: 12,
  },
  metricValue: { fontFamily: "var(--mono)", color: "#d7d8c9" },
  saveRow: {
    display: "flex",
    alignItems: "center",
    flexWrap: "wrap",
    gap: 20,
    marginTop: 22,
  },
  save: {
    backgroundColor: "var(--paper)",
    color: "var(--ink)",
    borderWidth: 1,
    borderStyle: "solid",
    borderColor: "var(--paper)",
    borderRadius: 3,
    padding: "13px 18px",
    fontSize: 12,
    fontWeight: 600,
    cursor: "pointer",
    minHeight: 44,
  },
  reset: {
    backgroundColor: "transparent",
    color: "#d7d8c9",
    border: 0,
    textDecoration: "underline",
    textUnderlineOffset: 4,
    cursor: "pointer",
    padding: 10,
    fontSize: 12,
  },
  status: {
    fontSize: 12,
    lineHeight: 1.6,
    minHeight: 39,
    color: "#d7d8c9",
    margin: "14px 0 0",
  },
  labFoot: {
    display: "flex",
    gap: 10,
    alignItems: "center",
    fontSize: 10,
    color: "#b9b8ad",
    marginTop: 26,
    lineHeight: 1.5,
  },
  supporting: {
    display: "flex",
    gap: 50,
    marginTop: 88,
    paddingTop: 35,
    borderTopWidth: 1,
    borderTopStyle: "solid",
    borderTopColor: "#ffffff30",
    "@media (max-width: 700px)": {
      flexDirection: "column",
      gap: 28,
      marginTop: 48,
    },
  },
  support: { flex: "1 1 0", minWidth: 0 },
  supportTitle: {
    fontSize: 20,
    lineHeight: 1.25,
    fontWeight: 500,
    margin: "14px 0 11px",
    letterSpacing: "-0.02em",
  },
  supportP: { fontSize: 13, lineHeight: 1.75, color: "#b9b8ad", margin: 0 },
  workflow: {
    display: "flex",
    gap: 90,
    "@media (max-width: 900px)": { flexDirection: "column", gap: 42 },
  },
  workflowLead: { flex: "1 1 0", minWidth: 0 },
  workflowP: {
    fontSize: 16,
    lineHeight: 1.65,
    maxWidth: 340,
    margin: "24px 0 35px",
    color: "var(--muted)",
  },
  steps: {
    flex: "1.15 1 0",
    listStyle: "none",
    padding: 0,
    margin: 0,
    minWidth: 0,
  },
  step: {
    display: "flex",
    gap: 27,
    paddingBlock: 25,
    borderTopWidth: 1,
    borderTopStyle: "solid",
    borderTopColor: "var(--rule)",
  },
  stepNumber: {
    fontSize: 12,
    color: "#ad4029",
    paddingTop: 4,
    fontFamily: "var(--mono)",
    flexShrink: 0,
  },
  stepTitle: {
    fontSize: 25,
    fontWeight: 530,
    letterSpacing: "-0.035em",
    lineHeight: 1.2,
    margin: "0 0 10px",
  },
  stepP: {
    fontSize: 14,
    lineHeight: 1.65,
    color: "var(--muted)",
    margin: 0,
    maxWidth: 460,
  },
  toolkit: {
    display: "flex",
    flexWrap: "wrap",
    gap: 12,
    marginTop: 25,
    paddingTop: 26,
    borderTopWidth: 1,
    borderTopStyle: "solid",
    borderTopColor: "var(--rule)",
  },
  chip: {
    borderWidth: 1,
    borderStyle: "solid",
    borderColor: "#bdbcb2",
    borderRadius: 2,
    padding: "9px 12px",
    fontSize: 11,
    color: "var(--muted)",
  },
  start: {
    backgroundColor: "var(--accent)",
    color: "var(--ink)",
    paddingTop: { default: 83, "@media (max-width: 600px)": 58 },
    paddingBottom: 56,
    position: "relative",
    overflow: "hidden",
  },
  startTop: {
    display: "flex",
    flexWrap: "wrap",
    justifyContent: "space-between",
    gap: 50,
    alignItems: "flex-end",
    "@media (max-width: 800px)": { alignItems: "flex-start", gap: 33 },
  },
  startH2: {
    flex: "2 1 700px",
    minWidth: 0,
    maxWidth: "100%",
    fontSize: {
      default: "clamp(65px, 7.8vw, 120px)",
      "@media (max-width: 600px)": "clamp(48px, 13.5vw, 80px)",
    },
    lineHeight: 0.97,
    letterSpacing: "-0.045em",
    fontWeight: 550,
    margin: 0,
  },
  startAside: { flex: "1 1 280px", minWidth: 0, maxWidth: 330 },
  startP: { fontSize: 16, lineHeight: 1.65, maxWidth: 330, margin: "0 0 24px" },
  commandArea: {
    display: "flex",
    gap: 28,
    alignItems: "center",
    justifyContent: "space-between",
    marginTop: 65,
    paddingTop: 30,
    borderTopWidth: 1,
    borderTopStyle: "solid",
    borderTopColor: "#20221d65",
    "@media (max-width: 700px)": {
      alignItems: "stretch",
      flexDirection: "column",
      gap: 18,
      marginTop: 43,
    },
  },
  commandIntro: { fontSize: 12, lineHeight: 1.6, maxWidth: 280, margin: 0 },
  command: {
    display: "flex",
    flexWrap: "wrap",
    alignItems: "center",
    justifyContent: "space-between",
    gap: 16,
    backgroundColor: "#20221d",
    color: "var(--paper)",
    padding: "12px 13px 12px 24px",
    minWidth: 0,
    width: 455,
    maxWidth: "100%",
    borderRadius: 3,
  },
  code: { fontFamily: "var(--mono)", fontSize: 14, overflowWrap: "anywhere" },
  copy: {
    display: "inline-flex",
    gap: 9,
    alignItems: "center",
    backgroundColor: "transparent",
    color: "var(--paper)",
    borderWidth: 1,
    borderStyle: "solid",
    borderColor: "#77796b",
    borderRadius: 2,
    padding: "10px 13px",
    fontSize: 11,
    cursor: "pointer",
    flexShrink: 0,
  },
  copyStatus: {
    fontSize: 12,
    lineHeight: 1.5,
    minHeight: 22,
    margin: "10px 0 0",
    textAlign: "right",
  },
  footer: { paddingBlock: 35 },
  footerTop: {
    display: "flex",
    alignItems: "center",
    justifyContent: "space-between",
    gap: 25,
    flexWrap: "wrap",
  },
  footerLinks: { display: "flex", flexWrap: "wrap", gap: 26, fontSize: 12 },
  footerBottom: {
    display: "flex",
    alignItems: "flex-start",
    justifyContent: "space-between",
    gap: 30,
    fontSize: 11,
    lineHeight: 1.6,
    color: "var(--muted)",
    borderTopWidth: 1,
    borderTopStyle: "solid",
    borderTopColor: "var(--rule)",
    paddingTop: 25,
    marginTop: 28,
    "@media (max-width: 600px)": { flexDirection: "column", gap: 15 },
  },
  research: { maxWidth: 540, margin: 0 },
});

function Arrow({ diagonal = false, size = 18, ...props }) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      fill="none"
      aria-hidden="true"
      {...props}
    >
      <path
        d={diagonal ? "M5 19 19 5M5 5h14v14" : "M4 12h16m-6-6 6 6-6 6"}
        stroke="currentColor"
        strokeWidth="1.5"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
    </svg>
  );
}
function Mark({ size = 29 }) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 32 32"
      fill="none"
      aria-hidden="true"
    >
      <path
        d="M16 2v28M2 16h28M6.1 6.1l19.8 19.8M6.1 25.9 25.9 6.1"
        stroke="currentColor"
        strokeWidth="2"
      />
      <circle cx="16" cy="16" r="10" stroke="currentColor" strokeWidth="1.5" />
    </svg>
  );
}
function Eyebrow({ children, light = false }) {
  return (
    <p {...stylex.props(s.eyebrow)}>
      <span className={light ? "index-dot light" : "index-dot"} />
      {children}
    </p>
  );
}
function cx(styles, name) {
  return stylex.props(styles).className + " " + name;
}

// Native scrolling drives only visible scenes. No perpetual animation loop.
function useScrollScenes() {
  useEffect(() => {
    const media = window.matchMedia("(prefers-reduced-motion: reduce)");
    const scenes = [...document.querySelectorAll("[data-scene]")];
    const visible = new Set();
    let frame = 0;
    const render = () => {
      frame = 0;
      if (document.hidden || media.matches) return;
      visible.forEach((el) => {
        const r = el.getBoundingClientRect();
        const p = Math.max(
          0,
          Math.min(1, (innerHeight - r.top) / (innerHeight + r.height)),
        );
        el.style.setProperty("--progress", p.toFixed(4));
      });
    };
    const schedule = () => {
      if (!frame && visible.size && !media.matches && !document.hidden)
        frame = requestAnimationFrame(render);
    };
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((e) =>
          e.isIntersecting ? visible.add(e.target) : visible.delete(e.target),
        );
        schedule();
      },
      { rootMargin: "100px" },
    );
    scenes.forEach((el) => observer.observe(el));
    const change = () => {
      scenes.forEach((el) => el.style.setProperty("--progress", "0.5"));
      schedule();
    };
    window.addEventListener("scroll", schedule, { passive: true });
    window.addEventListener("resize", schedule, { passive: true });
    document.addEventListener("visibilitychange", schedule);
    media.addEventListener("change", change);
    schedule();
    return () => {
      observer.disconnect();
      cancelAnimationFrame(frame);
      window.removeEventListener("scroll", schedule);
      window.removeEventListener("resize", schedule);
      document.removeEventListener("visibilitychange", schedule);
      media.removeEventListener("change", change);
    };
  }, []);
}

function TypeArt() {
  return (
    <div className="type-art" aria-hidden="true">
      <span className="type-baseline one" />
      <span className="type-baseline two" />
      <span className="type-baseline three" />
      <span className="type-a">Aa</span>
      <span className="type-note">A little tension. A lot of character.</span>
      <span className="type-cross">+</span>
    </div>
  );
}
function ColorArt() {
  return (
    <div className="color-art" aria-hidden="true">
      <div className="swatch swatch-one" />
      <div className="swatch swatch-two" />
      <div className="swatch swatch-three" />
      <div className="swatch swatch-four" />
      <span className="color-note">Hue → role → contrast</span>
    </div>
  );
}
function LayoutArt() {
  return (
    <div className="layout-art" aria-hidden="true">
      <div className="layout-frame">
        <div className="layout-dot" />
        <div className="layout-line long" />
        <div className="layout-line" />
        <div className="layout-columns">
          <span />
          <span />
          <span />
        </div>
        <div className="layout-small" />
      </div>
      <div className="layout-frame small">
        <div className="layout-dot" />
        <div className="layout-line long" />
        <div className="layout-line" />
        <div className="layout-columns">
          <span />
          <span />
        </div>
      </div>
      <span className="layout-annotation">Same intent. New space.</span>
    </div>
  );
}

const initialExpression = 46;
function Lab() {
  const [value, setValue] = useState(initialExpression);
  const [status, setStatus] = useState("");
  useEffect(() => {
    try {
      const saved = localStorage.getItem("design-theory-direction");
      if (saved !== null) {
        const parsed = JSON.parse(saved);
        if (
          typeof parsed.expression === "number" &&
          parsed.expression >= 0 &&
          parsed.expression <= 100
        ) {
          setValue(parsed.expression);
          setStatus("Your saved direction is restored.");
        }
      }
    } catch {
      setStatus("Local storage is unavailable. You can still explore.");
    }
  }, []);
  const weight = Math.round(360 + value * 3.8);
  const leading = (1.14 - value * 0.002).toFixed(2);
  const duration = Math.round(720 - value * 4);
  const update = (n) => {
    setValue(n);
    setStatus("Unsaved direction. Explore, then keep what works.");
  };
  const save = () => {
    try {
      localStorage.setItem(
        "design-theory-direction",
        JSON.stringify({ expression: value, version: 1 }),
      );
      setStatus("Direction saved in this browser. Return to pick up here.");
    } catch {
      setStatus("Could not save locally. Browser storage may be disabled.");
    }
  };
  return (
    <section id="relationships" {...stylex.props(s.dark, s.section)}>
      <div {...stylex.props(s.wrap)}>
        <Eyebrow light>02 / Feel the relationships</Eyebrow>
        <div {...stylex.props(s.labIntro)}>
          <h2 {...stylex.props(s.h2)}>
            A small shift.
            <br />
            <span className="serif light-serif">A different feeling.</span>
          </h2>
          <p {...stylex.props(s.labAside)}>
            Design choices pull on each other. Move one control and see type,
            space, color, and timing move with it.
          </p>
        </div>
        <div {...stylex.props(s.labLayout)}>
          <div
            className={cx(s.specimen, "specimen")}
            data-scene="specimen"
            style={{
              "--expression": value / 100,
              "--spec-weight": weight,
              "--spec-leading": leading,
              "--spec-duration": `${duration}ms`,
            }}
            aria-label="Live design specimen"
          >
            <div {...stylex.props(s.specimenLabel)}>
              <span>FIELD NOTES — VOL. 01</span>
              <Mark size={21} />
            </div>
            <h3 className={cx(s.specimenTitle, "specimen-title")}>
              Room
              <br />
              to move.
            </h3>
            <div className="specimen-shapes" aria-hidden="true">
              <span className="specimen-ring" />
              <span className="specimen-orbit" />
              <span className="specimen-sphere" />
              <span className="specimen-line" />
            </div>
            <p {...stylex.props(s.specimenBottom)}>
              Good things happen
              <br />
              between the elements.
            </p>
            <span className="specimen-page" aria-hidden="true">
              01—∞
            </span>
          </div>
          <div {...stylex.props(s.controls)}>
            <h3 {...stylex.props(s.controlTitle)}>
              Find your kind of balance.
            </h3>
            <p {...stylex.props(s.controlP)}>
              Start with a feeling. These linked values offer a direction you
              can adjust and revisit.
            </p>
            <div {...stylex.props(s.presets)} aria-label="Specimen directions">
              {[
                ["Quiet", 12],
                ["Considered", 46],
                ["Expressive", 90],
              ].map(([name, n]) => (
                <button
                  key={name}
                  className={cx(s.preset, "preset")}
                  aria-pressed={value === n}
                  onClick={() => update(n)}
                >
                  {name}
                </button>
              ))}
            </div>
            <label htmlFor="expression" className="range-title">
              Expression{" "}
              <span>
                {value}
                <span className="sr-only"> percent</span>
              </span>
            </label>
            <input
              id="expression"
              type="range"
              min="0"
              max="100"
              value={value}
              onChange={(e) => update(Number(e.target.value))}
              aria-describedby="demo-note"
              style={{ "--range-fill": `${value}%` }}
            />
            <div {...stylex.props(s.rangeLabels)}>
              <span>More room to breathe</span>
              <span>More presence</span>
            </div>
            <div {...stylex.props(s.metricRow)}>
              <span>Type weight</span>
              <span {...stylex.props(s.metricValue)}>{weight}</span>
            </div>
            <div {...stylex.props(s.metricRow)}>
              <span>Line height</span>
              <span {...stylex.props(s.metricValue)}>{leading}</span>
            </div>
            <div {...stylex.props(s.metricRow)}>
              <span>Transition time</span>
              <span {...stylex.props(s.metricValue)}>{duration} ms</span>
            </div>
            <div {...stylex.props(s.saveRow)}>
              <button {...stylex.props(s.save)} onClick={save}>
                Keep this direction <span aria-hidden="true">↗</span>
              </button>
              <button
                {...stylex.props(s.reset)}
                onClick={() => update(initialExpression)}
              >
                Reset
              </button>
            </div>
            <p {...stylex.props(s.status)} role="status">
              {status}
            </p>
            <p id="demo-note" {...stylex.props(s.labFoot)}>
              <span className="outline-dot" />
              Illustrative relationships. A starting point, not a design score.
            </p>
          </div>
        </div>
        <div {...stylex.props(s.supporting)}>
          <div {...stylex.props(s.support)}>
            <span className="support-symbol" aria-hidden="true">
              ↝
            </span>
            <h3 {...stylex.props(s.supportTitle)}>Motion with intention.</h3>
            <p {...stylex.props(s.supportP)}>
              Shape tension, timing, continuity, and release with editable
              relationships. Respect reduced motion and check real platform
              behavior.
            </p>
          </div>
          <div {...stylex.props(s.support)}>
            <span className="support-symbol material-symbol" aria-hidden="true">
              ◐
            </span>
            <h3 {...stylex.props(s.supportTitle)}>Give the surface a voice.</h3>
            <p {...stylex.props(s.supportP)}>
              Explore texture, roughness, and light. DOM finishes approximate
              materials; dedicated graphics can use PBR. Check readability on
              the final composite.
            </p>
          </div>
          <div {...stylex.props(s.support)}>
            <span className="support-symbol" aria-hidden="true">
              ↺
            </span>
            <h3 {...stylex.props(s.supportTitle)}>
              Keep the path, not just the result.
            </h3>
            <p {...stylex.props(s.supportP)}>
              Retain alternatives and where decisions came from. An optional
              local selector can choose viable paths; replay saved paths without
              another model call when inputs match.
            </p>
          </div>
        </div>
      </div>
    </section>
  );
}

function GetStarted() {
  const [status, setStatus] = useState("");
  const copy = async () => {
    try {
      if (!navigator.clipboard?.writeText)
        throw new Error("Clipboard unavailable");
      await navigator.clipboard.writeText("npm run build");
      setStatus("Copied! Run it from your configured source checkout.");
    } catch {
      setStatus("Could not copy. Select and copy the command above.");
    }
  };
  return (
    <section id="get-started" {...stylex.props(s.start)}>
      <div {...stylex.props(s.wrap)}>
        <Eyebrow>04 / Make it yours</Eyebrow>
        <div {...stylex.props(s.startTop)}>
          <h2 {...stylex.props(s.startH2)}>
            Start with your brief.
            <br />
            <span className="serif">Keep your taste.</span>
          </h2>
          <div {...stylex.props(s.startAside)}>
            <p {...stylex.props(s.startP)}>
              Get the source, follow its setup instructions, then build locally.
              Your tools. Your decisions.
            </p>
            <a href={REPO} {...stylex.props(s.button)}>
              Get the source <Arrow diagonal />
            </a>
          </div>
        </div>
        <div {...stylex.props(s.commandArea)}>
          <p {...stylex.props(s.commandIntro)}>
            <strong>From a configured source checkout</strong>
            <br />
            After setup, build the project locally.
          </p>
          <div {...stylex.props(s.command)}>
            <code {...stylex.props(s.code)}>npm run build</code>
            <button
              onClick={copy}
              {...stylex.props(s.copy)}
              aria-label="Copy command"
            >
              <svg
                width="14"
                height="14"
                viewBox="0 0 16 16"
                fill="none"
                aria-hidden="true"
              >
                <rect
                  x="5"
                  y="5"
                  width="9"
                  height="9"
                  rx="1"
                  stroke="currentColor"
                />
                <path d="M10 3V2H2v8h1" stroke="currentColor" />
              </svg>
              Copy command
            </button>
          </div>
        </div>
        <p {...stylex.props(s.copyStatus)} role="status">
          {status}
        </p>
      </div>
    </section>
  );
}

function App() {
  useScrollScenes();
  useEffect(() => {
    document.title = "Design Theory — Make every choice work together";
    let meta = document.querySelector('meta[name="description"]');
    if (!meta) {
      meta = document.createElement("meta");
      meta.name = "description";
      document.head.appendChild(meta);
    }
    meta.content =
      "A local-first toolkit for exploring typography, color, layout, and motion as one connected design. Start with your brief. Keep your taste.";
  }, []);
  return (
    <div {...stylex.props(s.shell)}>
      <a className="skip-link" href="#main">
        Skip to content
      </a>
      <div {...stylex.props(s.wrap)}>
        <header {...stylex.props(s.header)}>
          <a
            href="#"
            {...stylex.props(s.brand)}
            aria-label="Design Theory home"
          >
            <Mark />
            Design Theory
            <span className="brand-period" aria-hidden="true">
              •
            </span>
          </a>
          <span className="header-note">
            Independent tools.
            <br />
            Connected thinking.
          </span>
          <nav {...stylex.props(s.nav)} aria-label="Main navigation">
            <a href="#features" {...stylex.props(s.navLink)}>
              Features
            </a>
            <a href="#how-it-works" {...stylex.props(s.navLink)}>
              How it works
            </a>
            <a href="#get-started" {...stylex.props(s.navCta)}>
              Get started <Arrow diagonal size={15} />
            </a>
          </nav>
        </header>
      </div>
      <main id="main">
        <section aria-labelledby="hero-title" {...stylex.props(s.wrap)}>
          <div {...stylex.props(s.heroTop)}>
            <h1 id="hero-title" {...stylex.props(s.heroTitle)}>
              Make every choice
              <br />
              <span className="serif hero-serif">work together.</span>
            </h1>
            <div {...stylex.props(s.heroIntro)}>
              <p {...stylex.props(s.intro)}>
                A local-first toolkit for coding agents. Explore typography,
                color, layout, and motion as one connected design.
              </p>
              <a href="#features" {...stylex.props(s.button)}>
                Explore the tools <Arrow />
              </a>
            </div>
          </div>
          <div className={cx(s.artwork, "campaign")} data-scene="campaign">
            <img
              src="assets/sculpture.png"
              width="1672"
              height="941"
              fetchPriority="high"
              alt="Vermilion lacquer ring, rough chalk sphere, and chrome ribbon balanced on amber glass in warm studio light."
              className={cx(s.artImg, "campaign-image")}
            />
            <div className="art-shade" />
            <div {...stylex.props(s.artTop)}>
              <span className="tiny-cross">+</span>FORCES BECOME FORM
            </div>
            <div className="art-coordinate" aria-hidden="true">
              <span />
              01 — COMPOSITION
            </div>
            <div {...stylex.props(s.artBottom)}>
              <span {...stylex.props(s.artCaption)}>
                Different materials.
                <br />
                One shared language.
              </span>
              <a
                href="#features"
                {...stylex.props(s.artBadge)}
                aria-label="Scroll to features"
              >
                <Arrow style={{ transform: "rotate(90deg)" }} size={24} />
              </a>
            </div>
          </div>
          <div {...stylex.props(s.imageMeta)}>
            <span>The physics of better interfaces.</span>
            <span>Local-first / Open source / MIT</span>
          </div>
        </section>
        <section id="features" {...stylex.props(s.wrap, s.section)}>
          <Eyebrow>01 / A connected toolkit</Eyebrow>
          <div {...stylex.props(s.sectionLead)}>
            <h2 {...stylex.props(s.h2)}>
              Nothing works
              <br />
              <span className="serif">in isolation.</span>
            </h2>
            <p {...stylex.props(s.leadP)}>
              Give it a direction. Compare possibilities. Measure what lands.
              Make the relationships between your choices part of the design.
            </p>
          </div>
          <div {...stylex.props(s.featureRow)}>
            <article {...stylex.props(s.feature)}>
              <span {...stylex.props(s.number)}>01 — TYPE</span>
              <div {...stylex.props(s.featureArt)}>
                <TypeArt />
              </div>
              <h3 {...stylex.props(s.h3)}>Type that holds together.</h3>
              <p {...stylex.props(s.featureP)}>
                Font metrics, variable axes, tracking, leading, and line breaks
                work as a whole. Explore them together, then verify the actual
                browser or native output.
              </p>
            </article>
            <article {...stylex.props(s.feature)}>
              <span {...stylex.props(s.number)}>02 — COLOR</span>
              <div {...stylex.props(s.featureArt)}>
                <ColorArt />
              </div>
              <h3 {...stylex.props(s.h3)}>Color with a purpose.</h3>
              <p {...stylex.props(s.featureP)}>
                Explore perceptual OKLCH palettes, give each color a role, and
                check scoped text contrast. Harmony is a choice. Legibility is
                checked.
              </p>
            </article>
            <article {...stylex.props(s.feature)}>
              <span {...stylex.props(s.number)}>03 — SPACE</span>
              <div {...stylex.props(s.featureArt)}>
                <LayoutArt />
              </div>
              <h3 {...stylex.props(s.h3)}>Layout that listens.</h3>
              <p {...stylex.props(s.featureP)}>
                Connect hierarchy, grouping, and whitespace. Build relationships
                that respond to your content and available space, then check how
                they reflow.
              </p>
            </article>
          </div>
        </section>
        <Lab />
        <section id="how-it-works" {...stylex.props(s.wrap, s.section)}>
          <Eyebrow>03 / From intent to interface</Eyebrow>
          <div {...stylex.props(s.workflow)}>
            <div {...stylex.props(s.workflowLead)}>
              <h2 {...stylex.props(s.h2)}>
                A direction.
                <br />
                An exploration.
                <br />
                <span className="serif">A path to keep.</span>
              </h2>
              <p {...stylex.props(s.workflowP)}>
                Work with your coding agent, keep your judgment, and bring the
                result back to the real screen.
              </p>
              <a href={REPO} className="text-link">
                Look inside the toolkit <Arrow diagonal size={17} />
              </a>
              <div className="path-diagram" aria-hidden="true">
                <span className="path-node start-node" />
                <span className="path-branch" />
                <span className="path-node alternate-node" />
                <span className="path-node final-node" />
                <span className="path-dash" />
                <span className="path-label">explore → measure → keep</span>
              </div>
            </div>
            <ol {...stylex.props(s.steps)}>
              {[
                [
                  "Set a direction",
                  "Record the audience, content, and visual intent in DESIGN.md. Give your agent something clear to work toward.",
                ],
                [
                  "Explore the relationships",
                  "Compare coupled alternatives. See how choices in type, color, space, and motion change each other.",
                ],
                [
                  "Measure the result",
                  "Use real font shaping and browser or native geometry. Catch wrapping, clipping, and constraint failures in the actual output.",
                ],
                [
                  "Keep the good path",
                  "Save decisions, revisit values, and revalidate when the content or context changes. Keep the thinking editable.",
                ],
              ].map(([title, copy], i) => (
                <li key={title} {...stylex.props(s.step)}>
                  <span {...stylex.props(s.stepNumber)}>0{i + 1}</span>
                  <div>
                    <h3 {...stylex.props(s.stepTitle)}>{title}</h3>
                    <p {...stylex.props(s.stepP)}>{copy}</p>
                  </div>
                </li>
              ))}
            </ol>
          </div>
          <div className="toolkit-note">
            <p>Built to fit the way you work.</p>
            <span>
              Unix-composable TypeScript CLI, JSON output, and thin MCP
              wrappers. Optional interactive specimens and component inspection
              resources.
            </span>
          </div>
          <div {...stylex.props(s.toolkit)}>
            {[
              "TypeScript CLI",
              "MCP wrappers",
              "React + StyleX",
              "React Native",
              "Local-first after provisioning",
            ].map((t) => (
              <span key={t} {...stylex.props(s.chip)}>
                {t}
              </span>
            ))}
          </div>
          <p className="platform-note">
            Platform-specific verification still matters. The optional selector
            is neither an aesthetic judge nor a factual verifier. Authoring
            tools guide ordinary app code; shipping the optional evaluator is a
            separate choice.
          </p>
        </section>
        <GetStarted />
      </main>
      <footer {...stylex.props(s.wrap, s.footer)}>
        <div {...stylex.props(s.footerTop)}>
          <a href="#" {...stylex.props(s.brand)}>
            <Mark size={26} />
            Design Theory
          </a>
          <div {...stylex.props(s.footerLinks)}>
            <a href={REPO}>View on GitHub ↗</a>
            <a href="#get-started">Build something good ↑</a>
          </div>
        </div>
        <div {...stylex.props(s.footerBottom)}>
          <p {...stylex.props(s.research)}>
            Research in progress. Better design preference and lower overall
            build-token use have not yet been established.
          </p>
          <span>
            MIT licensed. Pay it forward. Contribute a fix.
            <br />
            Previously Physics of Design.
          </span>
          <span>
            Independent by design.
            <br />© {new Date().getFullYear()} Design Theory
          </span>
        </div>
      </footer>
    </div>
  );
}

export const appRoot = createRoot(document.getElementById("root"));
appRoot.render(<App />);
