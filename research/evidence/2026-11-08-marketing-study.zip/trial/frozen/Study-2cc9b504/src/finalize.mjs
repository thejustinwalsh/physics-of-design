// Optional static head polish after the supplied, unchanged build command.
import { readFile, writeFile } from "node:fs/promises";
let html = await readFile("public/index.html", "utf8");
html = html.replace(
  "<title>Marketing study</title>",
  "<title>Design Theory — Make every choice work together</title>",
);
if (!html.includes('name="description"'))
  html = html.replace(
    "</head>",
    '<meta name="description" content="A local-first toolkit for exploring typography, color, layout, and motion as one connected design. Start with your brief. Keep your taste."><meta name="theme-color" content="#f4f2e9"><link rel="icon" href="data:image/svg+xml,%3Csvg xmlns=%27http://www.w3.org/2000/svg%27 viewBox=%270 0 32 32%27%3E%3Crect width=%2732%27 height=%2732%27 rx=%276%27 fill=%27%23f4f2e9%27/%3E%3Cg stroke=%27%2323261f%27 fill=%27none%27 stroke-width=%271.5%27%3E%3Cpath d=%27M16 3v26M3 16h26M7 7l18 18M7 25 25 7%27/%3E%3Ccircle cx=%2716%27 cy=%2716%27 r=%279%27/%3E%3C/g%3E%3C/svg%3E"></head>',
  );
if (!html.includes("<noscript>"))
  html = html.replace(
    '<div id="root"></div>',
    '<div id="root"></div><noscript><p style="padding:2rem;font:1.2rem sans-serif">Design Theory — a local-first toolkit for connected design. Enable JavaScript to explore the interactive story, or <a href="https://github.com/thejustinwalsh/physics-of-design">get the source on GitHub</a>.</p></noscript>',
  );
await writeFile("public/index.html", html);
