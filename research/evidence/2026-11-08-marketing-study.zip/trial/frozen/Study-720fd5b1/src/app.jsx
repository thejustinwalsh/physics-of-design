import React, { useEffect, useRef, useState } from "react";
import { createRoot } from "react-dom/client";
import * as stylex from "@stylexjs/stylex";
import decisions from "./design-values.json";

const sx = stylex.create({
  wrap: {
    width: "100%",
    maxWidth: 1600,
    marginInline: "auto",
    paddingInline: {
      default: 64,
      "@media (max-width: 1000px)": 36,
      "@media (max-width: 600px)": 22,
    },
    boxSizing: "border-box",
  },
  row: { display: "flex", alignItems: "center" },
  spread: {
    display: "flex",
    alignItems: "center",
    justifyContent: "space-between",
    gap: 24,
  },
  column: { display: "flex", flexDirection: "column" },
  button: {
    display: "inline-flex",
    alignItems: "center",
    justifyContent: "space-between",
    gap: 28,
    minHeight: 54,
    paddingBlock: 14,
    paddingInline: 24,
    borderRadius: 3,
    fontWeight: 600,
    textDecoration: "none",
    boxSizing: "border-box",
    borderWidth: 1,
    borderStyle: "solid",
    borderColor: "transparent",
    cursor: "pointer",
    fontSize: 15,
    lineHeight: 1.4,
  },
  primary: {
    backgroundColor: "#e14a23",
    color: "#161713",
    ":hover": { backgroundColor: "#ef643f" },
  },
  dark: {
    backgroundColor: "#1b1d19",
    color: "#f2efe7",
    ":hover": { backgroundColor: "#353830" },
  },
  outline: {
    borderColor: "#787b70",
    backgroundColor: "transparent",
    color: "#eeeae1",
    ":hover": { backgroundColor: "#31352d" },
  },
  label: {
    fontSize: 11,
    letterSpacing: "0.12em",
    textTransform: "uppercase",
    fontWeight: 600,
    lineHeight: 1.5,
  },
  body: { fontSize: 18, lineHeight: 1.6 },
  small: { fontSize: 13, lineHeight: 1.6 },
  section: { paddingBlock: { default: 110, "@media (max-width: 600px)": 72 } },
});
const repo = "https://github.com/thejustinwalsh/physics-of-design";
const Arrow = ({ diagonal = false, ...props }) => (
  <span aria-hidden="true" {...props}>
    {diagonal ? "↗" : "↗"}
  </span>
);
function Mark() {
  return (
    <svg
      className="brand-mark"
      viewBox="0 0 36 36"
      fill="none"
      aria-hidden="true"
    >
      <circle cx="18" cy="18" r="14" stroke="currentColor" strokeWidth="2" />
      <ellipse
        cx="18"
        cy="18"
        rx="7"
        ry="16"
        transform="rotate(40 18 18)"
        stroke="currentColor"
        strokeWidth="2"
      />
      <path d="M4 18h28" stroke="currentColor" strokeWidth="1.5" />
    </svg>
  );
}
function SectionLabel({ children, num }) {
  return (
    <div className={`${stylex.props(sx.label).className} section-label`}>
      <span className="small-cross" aria-hidden="true">
        +
      </span>
      {num} — {children}
    </div>
  );
}

function useScrollScene() {
  useEffect(() => {
    const media = window.matchMedia("(prefers-reduced-motion: reduce)");
    let frame = 0;
    let observed = new Set();
    const scenes = [...document.querySelectorAll("[data-scene]")];
    const update = () => {
      frame = 0;
      if (document.hidden || media.matches) return;
      const vh = innerHeight;
      observed.forEach((el) => {
        const r = el.getBoundingClientRect();
        const p = Math.max(0, Math.min(1, (vh - r.top) / (vh + r.height)));
        el.style.setProperty("--progress", p.toFixed(4));
        el.style.setProperty("--drift", `${((p - 0.5) * 110).toFixed(2)}px`);
      });
    };
    const request = () => {
      if (!frame && !document.hidden && !media.matches)
        frame = requestAnimationFrame(update);
    };
    const io = new IntersectionObserver(
      (entries) => {
        entries.forEach((e) => {
          e.isIntersecting ? observed.add(e.target) : observed.delete(e.target);
        });
        request();
      },
      { rootMargin: "120px" },
    );
    scenes.forEach((el) => io.observe(el));
    const change = () => {
      scenes.forEach((el) => {
        el.style.setProperty("--progress", ".5");
        el.style.setProperty("--drift", "0px");
      });
      request();
    };
    addEventListener("scroll", request, { passive: true });
    addEventListener("resize", request);
    document.addEventListener("visibilitychange", request);
    media.addEventListener("change", change);
    request();
    return () => {
      cancelAnimationFrame(frame);
      io.disconnect();
      removeEventListener("scroll", request);
      removeEventListener("resize", request);
      document.removeEventListener("visibilitychange", request);
      media.removeEventListener("change", change);
    };
  }, []);
}
function Header() {
  return (
    <header className={`${stylex.props(sx.wrap, sx.spread).className} header`}>
      <a className="brand" href="#top" aria-label="Design Theory home">
        <Mark />
        <span>
          Design Theory<span className="brand-sub">FORCES BECOME FORM</span>
        </span>
      </a>
      <nav aria-label="Main navigation">
        <a href="#features">Features</a>
        <a href="#how-it-works">How it works</a>
        <a href="#get-started" className="nav-cta">
          Get started <Arrow />
        </a>
      </nav>
    </header>
  );
}
function Hero() {
  return (
    <>
      <section
        className={`${stylex.props(sx.wrap).className} hero`}
        aria-labelledby="hero-title"
        data-scene
      >
        <div className="hero-copy">
          <p className={`${stylex.props(sx.label).className} eyebrow`}>
            <span className="live-dot" />
            LOCAL-FIRST. OPEN-ENDED.
          </p>
          <h1 id="hero-title">
            Make every
            <br />
            choice work
            <br />
            <em>together.</em>
          </h1>
          <p className="hero-description">
            A local-first toolkit that helps coding agents explore typography,
            color, layout, and motion as one connected design.
          </p>
          <div className="hero-actions">
            <a href="#features" {...stylex.props(sx.button, sx.dark)}>
              Explore the tools <span aria-hidden="true">↓</span>
            </a>
            <a href={repo} className="text-link">
              View on GitHub <Arrow />
            </a>
          </div>
        </div>
        <div className="hero-art">
          <div className="campaign-crop">
            <img
              className="campaign-image"
              src="assets/sculpture.png"
              alt="Red lacquer ring, rough stone sphere, and chrome orbit balanced on translucent amber glass."
              fetchPriority="high"
            />
          </div>
          <div className={`${stylex.props(sx.label).className} art-topline`}>
            <span>STUDY IN RELATIONSHIPS</span>
            <span>FIG. 01</span>
          </div>
          <div className="orbit-stamp" aria-hidden="true">
            <svg viewBox="0 0 80 80">
              <circle cx="40" cy="40" r="24" />
              <ellipse
                cx="40"
                cy="40"
                rx="34"
                ry="12"
                transform="rotate(-38 40 40)"
              />
              <circle cx="62" cy="22" r="5" className="stamp-dot" />
            </svg>
            <span>
              IN GOOD
              <br />
              RELATION
            </span>
          </div>
          <p className="art-caption">
            <span>Different forces. One composition.</span>
            <span>MATERIAL STUDY</span>
          </p>
        </div>
        <div className="hero-bottom">
          <span>Give it a direction. See what takes shape.</span>
          <a href="#features">
            SCROLL TO EXPLORE <span aria-hidden="true">↓</span>
          </a>
        </div>
      </section>
      <div
        className="discipline-strip"
        aria-label="Connected design disciplines"
      >
        <span>Typography</span>
        <i>✳</i>
        <span>Color</span>
        <i>✳</i>
        <span>Layout</span>
        <i>✳</i>
        <span>Motion</span>
        <i>✳</i>
        <span>Material</span>
      </div>
    </>
  );
}

function TypeComposition() {
  return (
    <div
      className="type-composition"
      data-scene
      aria-label="An expressive typography and color composition"
    >
      <span className="composition-meta">TYPE / COLOR / SPACE</span>
      <div className="composition-orbit" aria-hidden="true" />
      <span className="type-a" aria-hidden="true">
        Aa
        <span className="type-baseline" />
      </span>
      <span className="composition-note">
        A little tension.
        <br />
        <em>A lot of possibility.</em>
      </span>
      <div
        className="palette-swatches"
        aria-label="Warm paper, orange, sage, and ink palette"
      >
        <span />
        <span />
        <span />
        <span />
      </div>
      <span className="composition-bottom">
        Separate choices. Shared character. <span aria-hidden="true">↗</span>
      </span>
    </div>
  );
}
function Features() {
  return (
    <section
      id="features"
      className={`${stylex.props(sx.wrap, sx.section).className} features`}
      aria-labelledby="features-title"
    >
      <SectionLabel num="01">The connected toolkit</SectionLabel>
      <div className="section-intro">
        <h2 id="features-title">
          Nothing works
          <br />
          in <em>isolation.</em>
        </h2>
        <p>
          Good design happens between the choices. Explore those relationships,
          check what lands, and keep every decision yours to change.
        </p>
      </div>
      <div className="feature-editorial">
        <TypeComposition />
        <div className="feature-pair">
          <article>
            <span className="feature-index">01 / TYPOGRAPHY</span>
            <h3>Find your rhythm.</h3>
            <p>
              Font axes, tracking, leading, measure, and line breaks move
              together. Explore the whole system, then verify the type in the
              actual browser or native view.
            </p>
          </article>
          <article>
            <span className="feature-index">02 / COLOR</span>
            <h3>Make color mean something.</h3>
            <p>
              Explore perceptual OKLCH palettes, give each color a role, and
              check text contrast. Harmony is a choice. Legibility gets checked.
            </p>
          </article>
        </div>
      </div>
      <div className="feature-trio">
        <article>
          <div className="feature-symbol layout-symbol" aria-hidden="true">
            <i />
            <i />
            <i />
          </div>
          <span className="feature-index">03 / LAYOUT</span>
          <h3>Room to respond.</h3>
          <p>
            Connect hierarchy, grouping, and whitespace. Let the layout adapt to
            the content and the space it actually has.
          </p>
        </article>
        <article>
          <div className="feature-symbol motion-symbol" aria-hidden="true">
            <i />
            <i />
            <i />
          </div>
          <span className="feature-index">04 / MOTION</span>
          <h3>A reason to move.</h3>
          <p>
            Shape tension, timing, and release through editable motion
            relationships. Keep reduced motion and real platform behavior in the
            picture.
          </p>
        </article>
        <article>
          <div className="feature-symbol material-symbol" aria-hidden="true">
            <i />
          </div>
          <span className="feature-index">05 / MATERIALS & LIGHT</span>
          <h3>Make the surface speak.</h3>
          <p>
            Explore texture, roughness, and light. DOM finishes are visual
            approximations; dedicated graphics can use PBR. Check readability on
            the final surface.
          </p>
        </article>
      </div>
    </section>
  );
}

function Demo() {
  const [mood, setMood] = useState(55);
  const [saved, setSaved] = useState(null);
  const [message, setMessage] = useState("");
  const m = mood / 100;
  const moodName = mood < 34 ? "Quiet" : mood < 70 ? "Balanced" : "Expressive";
  const vars = {
    "--spec-size": `${36 + m * 28}px`,
    "--spec-leading": `${1.15 - m * 0.19}`,
    "--spec-tracking": `${-0.015 - m * 0.04}em`,
    "--spec-space": `${38 - m * 12}px`,
    "--spec-color": `hsl(${28 - m * 16} ${20 + m * 58}% ${88 - m * 25}%)`,
    "--spec-orbit": `${-25 + m * 60}deg`,
  };
  function save() {
    setSaved(mood);
    setMessage(`${moodName} path saved for this visit.`);
  }
  function replay() {
    if (saved !== null) {
      setMood(saved);
      setMessage("Saved choices restored.");
    }
  }
  return (
    <section className="demo-section" data-scene aria-labelledby="demo-title">
      <div {...stylex.props(sx.wrap)}>
        <SectionLabel num="02">Try a relationship</SectionLabel>
        <div className="demo-layout">
          <div className="demo-copy">
            <h2 id="demo-title">
              Change the mood.
              <br />
              <em>Keep the thread.</em>
            </h2>
            <p>
              Pull one thread and see the rest respond. Here, type, space, and
              color change as a family.
            </p>
            <div className="demo-controls">
              <div className="slider-heading">
                <label htmlFor="mood">Set the expression</label>
                <output htmlFor="mood">{moodName}</output>
              </div>
              <input
                id="mood"
                type="range"
                min="0"
                max="100"
                value={mood}
                onChange={(e) => {
                  setMood(Number(e.target.value));
                  setMessage("");
                }}
                aria-describedby="demo-help"
              />
              <div className="range-labels">
                <span>Quiet</span>
                <span>Expressive</span>
              </div>
              <div className="save-actions">
                <button onClick={save}>
                  Save this path <span aria-hidden="true">↗</span>
                </button>
                <button onClick={replay} disabled={saved === null}>
                  Replay saved <span aria-hidden="true">↺</span>
                </button>
              </div>
              <p className="demo-feedback" role="status">
                {message || "Explore. Keep a path. Come back to it."}
              </p>
            </div>
            <p id="demo-help" className="demo-disclaimer">
              An illustrative specimen, not a design score. Use the arrow keys
              to make small adjustments.
            </p>
          </div>
          <div className="specimen-assembly">
            <div className="specimen-orbit" aria-hidden="true" />
            <div className="specimen" style={vars}>
              <div className="specimen-top">
                <span>AN EXPERIMENT IN FEELING</span>
                <span>DT.</span>
              </div>
              <div className="specimen-art" aria-hidden="true">
                <div className="specimen-disc" />
                <div className="specimen-wire" />
                <span className="specimen-satellite satellite-one" />
                <span className="specimen-satellite satellite-two" />
              </div>
              <h3>
                Form follows
                <br />
                <em>feeling.</em>
              </h3>
              <div className="specimen-bottom">
                <span>
                  A shared language.
                  <br />A thousand possible expressions.
                </span>
                <span aria-hidden="true">↗</span>
              </div>
            </div>
            <div className="specimen-footnote">
              <span>TYPE + SPACE + COLOR</span>
              <span>LIVE SPECIMEN / {moodName.toUpperCase()}</span>
            </div>
          </div>
        </div>
        <div className="revisit">
          <span className="revisit-icon" aria-hidden="true">
            ↺
          </span>
          <h3>
            Good decisions
            <br />
            deserve a way back.
          </h3>
          <p>
            Retain alternatives and where they came from. An optional local
            selector can choose among viable options; saved paths replay without
            another model call when the inputs still match.
          </p>
        </div>
      </div>
    </section>
  );
}
const steps = [
  [
    "Set a direction.",
    "Start with the audience, content, and visual intent. Record it in DESIGN.md. Give the work a point of view.",
  ],
  [
    "Explore the relationships.",
    "Compare coupled alternatives. See what changes together, instead of guessing one number at a time.",
  ],
  [
    "Measure what lands.",
    "Use real font shaping and browser or native geometry. Catch wrapping, clipping, and constraint failures.",
  ],
  [
    "Keep the good path.",
    "Save the decisions. Revisit the values. Revalidate when your content or context changes.",
  ],
];
function Workflow() {
  return (
    <section
      id="how-it-works"
      {...stylex.props(sx.wrap, sx.section)}
      aria-labelledby="workflow-title"
    >
      <SectionLabel num="03">From intent to interface</SectionLabel>
      <div className="workflow-heading">
        <h2 id="workflow-title">
          A point of view.
          <br />
          <em>A path forward.</em>
        </h2>
        <p>
          Your taste sets the direction.
          <br />
          The tools help you follow through.
        </p>
      </div>
      <div className="workflow-steps">
        {steps.map(([title, body], i) => (
          <article key={title}>
            <span className="step-num">
              0{i + 1}
              <span aria-hidden="true">{i === 3 ? "↗" : "→"}</span>
            </span>
            <h3>{title}</h3>
            <p>{body}</p>
          </article>
        ))}
      </div>
      <div className="tooling-note">
        <span className="code-symbol" aria-hidden="true">
          {">_"}
        </span>
        <div>
          <h3>Fits the way you build.</h3>
          <p>
            A Unix-composable TypeScript CLI with JSON output and thin MCP
            wrappers. React + StyleX and React Native mappings, with optional
            interactive specimens and component inspection. Verify each platform
            where it runs.
          </p>
        </div>
        <span className="tooling-tag">
          LOCAL-FIRST
          <br />
          EDITABLE BY DESIGN
        </span>
      </div>
    </section>
  );
}
function GetStarted() {
  const [copy, setCopy] = useState("Copy command");
  const [status, setStatus] = useState("");
  async function copyCommand() {
    try {
      if (!navigator.clipboard) throw Error("Clipboard unavailable");
      await navigator.clipboard.writeText("npm run build");
      setCopy("Copied");
      setStatus("Copied npm run build to your clipboard.");
    } catch {
      setCopy("Try again");
      setStatus("Could not copy. Select and copy the command below.");
    }
  }
  return (
    <section
      id="get-started"
      className="get-started"
      aria-labelledby="start-title"
    >
      <div {...stylex.props(sx.wrap)}>
        <SectionLabel num="04">Make it yours</SectionLabel>
        <div className="start-layout">
          <div>
            <h2 id="start-title">
              Start with your brief.
              <br />
              <em>Keep your taste.</em>
            </h2>
            <p>
              Get the source, follow its setup instructions,
              <br className="desktop-break" /> then build locally.
            </p>
            <a href={repo} {...stylex.props(sx.button, sx.dark)}>
              Get the source <Arrow />
            </a>
          </div>
          <div className="command-area">
            <div className="terminal">
              <div className="terminal-head">
                <span>SOURCE CHECKOUT</span>
                <span aria-hidden="true">● ● ●</span>
              </div>
              <div className="command-line">
                <span aria-hidden="true">$</span>
                <code>npm run build</code>
              </div>
              <button onClick={copyCommand} className="copy-button">
                <svg viewBox="0 0 18 18" fill="none" aria-hidden="true">
                  <rect
                    x="6"
                    y="6"
                    width="9"
                    height="10"
                    rx="1"
                    stroke="currentColor"
                  />
                  <path d="M11 6V2H2v10h4" stroke="currentColor" />
                </svg>
                {copy}
              </button>
              <p role="status" className="copy-feedback">
                {status}
              </p>
            </div>
            <p className="command-note">
              Run from the source checkout after setup.
              <br />
              Local-first after provisioning. No required hosted service.
            </p>
          </div>
        </div>
        <div className="start-facts">
          <span>MIT-licensed source</span>
          <span>Build ordinary application code</span>
          <span>
            Contribute a fix. Pass it forward. <Arrow />
          </span>
        </div>
      </div>
    </section>
  );
}
function Footer() {
  return (
    <footer {...stylex.props(sx.wrap)}>
      <div className="footer-top">
        <a className="brand" href="#top">
          <Mark />
          <span>Design Theory</span>
        </a>
        <p>The physics of better interfaces.</p>
        <a className="text-link" href={repo}>
          GitHub <Arrow />
        </a>
      </div>
      <div className="footer-bottom">
        <p>
          Research in progress. Better design preference and lower overall
          build-token use have not yet been established.
        </p>
        <p>
          The optional selector chooses; it does not judge aesthetics or verify
          facts.
          <br />
          Shipping an evaluator is a separate choice.
        </p>
        <span>© 2026 Design Theory</span>
      </div>
    </footer>
  );
}
function App() {
  useScrollScene();
  useEffect(() => {
    for (const [key, value] of Object.entries({
      "--title-size": decisions.titleSize + "px",
      "--title-leading": decisions.titleLeading,
      "--title-tracking": decisions.titleTracking + "em",
      "--section-size": decisions.sectionSize + "px",
      "--section-gap": decisions.sectionGap + "px",
    }))
      document.documentElement.style.setProperty(key, value);
    document.title = "Design Theory — Make every choice work together.";
    const description = document.createElement("meta");
    description.name = "description";
    description.content =
      "A local-first toolkit for typography, color, layout, motion, and materials. Explore connected choices, measure the result, and keep your taste.";
    document.head.append(description);
    return () => description.remove();
  }, []);
  return (
    <>
      <a href="#main" className="skip-link">
        Skip to content
      </a>
      <div id="top" />
      <Header />
      <main id="main" tabIndex={-1}>
        <Hero />
        <Features />
        <Demo />
        <Workflow />
        <GetStarted />
      </main>
      <Footer />
    </>
  );
}
createRoot(document.getElementById("root")).render(<App />);
