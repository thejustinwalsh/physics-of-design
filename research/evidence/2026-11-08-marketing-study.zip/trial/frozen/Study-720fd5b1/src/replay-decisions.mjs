import {readFile,writeFile} from 'node:fs/promises';import {createHash} from 'node:crypto';import path from 'node:path';
const request=JSON.parse(await readFile('receipts/decision-request.json','utf8'));const bytes=await readFile('receipts/decision-run-2.json');const result=JSON.parse(bytes);request.mode='replay';request.recipe={$designFile:path.resolve('receipts/decision-run-2.json'),sha256:createHash('sha256').update(bytes).digest('hex'),pointer:'/recipe'};
await writeFile('receipts/replay-request.json',JSON.stringify(request,null,2));
const values={...result.stages['hero-type'].assignment,...result.stages['section-rhythm'].assignment};await writeFile('src/design-values.json',JSON.stringify(values,null,2));
