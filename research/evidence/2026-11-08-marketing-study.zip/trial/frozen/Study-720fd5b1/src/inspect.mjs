import {chromium,webkit} from 'playwright';
import {writeFile} from 'node:fs/promises';
const browser=await chromium.launch();const checks=[];
for(const [name,width,height] of [['desktop',1440,1000],['ipad',820,1180],['phone',390,844]]){
const page=await browser.newPage({viewport:{width,height},deviceScaleFactor:1});let errors=[];page.on('pageerror',e=>errors.push(String(e)));page.on('console',m=>{if(m.type()==='error')errors.push(m.text())});
await page.goto('http://127.0.0.1:4173');await page.evaluate(()=>document.fonts.ready);await page.waitForTimeout(250);await page.screenshot({path:`receipts/${name}-full.png`,fullPage:true});
const result=await page.evaluate(()=>({width:innerWidth,scrollWidth:document.documentElement.scrollWidth,height:document.documentElement.scrollHeight,fonts:document.fonts.check('500 100px "Roboto Flex"'),sections:[...document.querySelectorAll('h1,h2')].map(e=>({text:e.textContent,rect:e.getBoundingClientRect().toJSON()})),overflow:[...document.querySelectorAll('body *')].filter(e=>{let r=e.getBoundingClientRect();return r.width>0&&(r.left< -1||r.right>innerWidth+1)&&getComputedStyle(e).position!=='absolute'&&getComputedStyle(e).position!=='fixed'}).map(e=>({tag:e.tagName,class:e.className,rect:e.getBoundingClientRect().toJSON()}))}));checks.push({name,...result,errors});await page.close();}
await browser.close();await writeFile('receipts/initial-browser.json',JSON.stringify(checks,null,2));console.log(checks.map(({name,width,scrollWidth,height,errors,overflow})=>({name,width,scrollWidth,height,errors,overflow:overflow.length})));
