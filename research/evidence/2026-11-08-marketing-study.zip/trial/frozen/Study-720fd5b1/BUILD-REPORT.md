# Design Theory — build report

## Delivered

`public/index.html` is the entry point to the complete static marketing site. React + StyleX source is in `src/app.jsx`; visual effects, fonts, and responsive rules are in `public/base.css`. `src/design-values.json` retains the selected values. Build with `npm run build`, then serve `public/` over local HTTP. The supplied build script and package manifest are unchanged.

The page follows the recorded “Forces become form” direction: warm paper, dark ink, orange, large expressive typography, and the licensed sculpture campaign. It includes all six feature meanings, the four-step workflow, repository links, an illustrative coupled-choice specimen, per-visit save/replay, and a real clipboard action for `npm run build`. Success and failure feedback are visible. The evidence boundary remains visible in the footer.

Native scrolling drives multiple layers: campaign-image drift, the type/color composition, and the middle-page specimen’s card, sphere, orbit, and satellites. Controls remain stationary. Reduced motion removes spatial parallax while retaining the entire page and demonstration. Scroll updates are scheduled through RAF only when needed, limited to intersecting scenes, and paused while the document is hidden. React cleanup cancels RAF, disconnects the observer, and removes listeners; that cleanup was reviewed in source, not separately profiled through an unmount harness.

## Toolkit and local selector

Read the supplied skill and the relevant decision, typography, and composition references. Discovered `decision run --schema`; inspected the current DESIGN.md identity with `context inspect`. Requests bind the design hash, actual font hash, content, and intent. Used exported `inspectFont` and `analyzeComposition` functions, as well as the CLI.

The narrow staged decision compares title size, leading, and tracking, then conditions section hierarchy on the chosen title. The request explicitly passes `selector.gguf` from the supplied `modelPath`, with the Qwen3.5-4B profile. The successful run performed 21 numeric evaluations and one completed real local selector readout. It chose 118px / 0.94 leading / −0.05em tracking; the dependent stage chose 60px section headings and 32px adjacent spacing. Responsive caps and topology remain independently authored.

The first selector attempt failed to initialize Metal inside the sandbox. Its full result, alternatives, and raw wrapper receipts are retained. The same request succeeded with approved execution outside the sandbox. There were two actual selector invocation attempts in total, one completed readout, and no injected selector.

A hash-bound replay revalidated six retained assignments with two cache hits, **zero searches and zero neural calls**. All three title finalists were measured at four widths in both engines (24 measurements); all three section finalists were measured at three widths in both engines (18 measurements). Browser geometry and current application/CSS hashes are retained. These checks establish fit and declared alignment, not aesthetic superiority.

## Actual checks

Final suite: **134 checks passed; zero failed**, in installed Playwright Chromium and WebKit.

- Desktop 1440×1000, iPad-size 820×1180, and phone 390×844: loaded content/fonts, asset requests, page errors, visible navigation, anchors, and horizontal fit.
- Continuous resizing through 23 widths from 240 to 1600px, across breakpoints and back, without reloading or losing demo state.
- Changed hero/body/feature text; separate 200% text-size simulation: natural reflow and no heading overflow at all three sizes in both engines.
- Pointer slider, Home/End/arrow keys, coupled style changes, save, replay, focus traversal, skip link, and repository destinations.
- Chromium uses Tab for traversal. This WebKit build uses macOS-style Option-Tab to reach all controls; default Tab skips them. The investigation and resulting test policy are recorded.
- Actual Chromium clipboard write/read returned exactly `npm run build`. Separate simulated clipboard success/refusal tests verify both feedback paths in each layout and engine.
- Three intermediate scroll states per scenario; distinct transforms recorded. Desktop frame screenshots were inspected. Reduced-motion transforms are calm and the slider remains operable.
- Computed text contrast checked on known surfaces, excluding decorative/disabled marks. Artwork annotations received opaque ink backings after image sampling exposed crop-dependent contrast. Their final contrast is 14.36:1 across the sampled phone/iPad/desktop scroll positions.
- Final desktop, tablet, phone, changed-text, enlarged-text, demo, and title-finalist screenshots saved. Hero and enlarged phone views were visually inspected. `npm run build` completes without warnings.

## Receipts and limits

Start with `receipts/verification.json`, `final-manifest.json`, `decision-run-2.json`, `decision-replay.json`, `text-contrast.json`, `image-contrast-matrix.json`, and the rendered-finalist JSON files. Earlier failures and test corrections remain in `verification-run-*.json`, selector logs, and `resolved-failures.md`.

No unresolved site failure was observed in the final checks. This is browser emulation, not physical-device verification. No screen-reader audit, Firefox run, physical Safari/iOS test, actual user font-preference test, exhaustive width proof, or production repository setup was performed. Text enlargement was simulated; external repository URLs were checked locally rather than fetched. The demo saves only for the current visit.

Assistance used: one Codex builder, the supplied Design Theory toolkit, its provisioned local Qwen3.5-4B selector, installed Playwright, and existing dependencies. No child agents, external inference, web research, downloaded packages/assets, or image generation. Campaign art and fonts are supplied assets; additional graphics are code-native CSS/SVG. No claim of validated design preference or token savings is made.
